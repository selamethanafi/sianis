<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//============================================================+
// Dimutakhirkan	: Sen 04 Jan 2016 07:59:25 WIB 
// Nama Berkas 		: login_form.php
// Lokasi      		: application/views/
// Author      		: Selamet Hanafi
//             		  selamethanafi@yahoo.co.id
//
// (c) Copyright:
//               MAN Tengaran
//               www.mantengaran.sch.id
//               admin@mantengaran.sch.id
//
// License:
//    Copyright (C) 2014 MAN Tengaran
//    Informasi detil ada di LISENSI.TXT 
//============================================================+
?>
<div id="login_form">
	<?php
	if(!empty($galat))
	{
	 echo '<font color="red">'.$galat.'</font>';
	}
	?>
	<h1>Silakan Login lha yo</h1>
    <?php 
	$this->load->helper('captcha');
	$word = strtoupper(random_string('alnum','4'));
	$vals = array(
	'word' => $word,
    'img_path' => './captcha/',
    'img_url' => ''.base_url().'captcha/',
	'font_path'     => $this->config->item('fonts_path').'/verdanab.ttf',
	'img_width' => '130',
	'font_size' => '12',
    'img_height' => 50,
    'expiration' => 600,
	'colors'        => array(
                'background' => array(255, 255, 255),
                'border' => array(255, 255, 255),
                'text' => array(0, 0, 0),
                'grid' => array(255, 255,150)
		)
    );

$cap = create_captcha($vals);

$data = array(
    'captcha_time' => $cap['time'],
    'ip_address' => $this->input->ip_address(),
    'word' => $cap['word']
    );

$query = $this->db->insert_string('captcha', $data);
$this->db->query($query);

	echo form_open('login/masuk');
	echo 'Username';
	echo form_input('usernameteks');
	echo 'Password';
	echo form_password('passwordteks');
	echo 'Tulis Kode keamanan dibawah ini:';
	echo $cap['image'];
	echo '<input type="text" name="captcha" value="" />';
	echo form_submit('submit', 'Login');
	echo form_close();

echo 'Lupa atau reset password, <a href="'.base_url().'index.php/login/lupasandi">di sini</a>';
?>
</div><!-- end login_form-->

