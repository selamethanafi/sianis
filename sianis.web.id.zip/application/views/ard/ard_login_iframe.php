<div class="container-fluid">
<iframe src="<?php echo base_url();?>ard/login" width="100%" height="600"></iframe>
</div>
