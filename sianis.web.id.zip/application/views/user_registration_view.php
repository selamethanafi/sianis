<!DOCTYPE html>
<html lang="id">
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Borang Pendaftaran Sianis</title>
	<link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="container">
<div class="row">
	<?php echo $this->session->flashdata('msg'); ?>
	<div class="col-md-6 col-md-offset-3">
		<?php echo $this->session->flashdata('verify_msg'); ?>
	</div>
</div>

<div class="row">
	<div class="col-md-6 col-md-offset-3">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4>Borang Pendaftaran Sianis</h4>
			</div>
			<div class="panel-body">
				<?php $attributes = array("name" => "registrationform");
				echo form_open("user/register", $attributes);?>
				<div class="form-group">
					<label for="name">Nama Pengguna</label>
					<input class="form-control" name="username" placeholder="Nama Pengguna" type="text" value="<?php echo set_value('username'); ?>" />
					<span class="text-info">Nama pengguna hanya berisi karakter huruf, angka, atau _</span>
					<span class="text-danger"><?php echo form_error('username'); ?></span>
				</div>

				<div class="form-group">
					<label for="name">Nama</label>
					<input class="form-control" name="nama" placeholder="Nama Anda" type="text" value="<?php echo set_value('lname'); ?>" />
					<span class="text-danger"><?php echo form_error('nama'); ?></span>
				</div>
				<div class="form-group">
					<label for="email">Email Anda</label>
					<input class="form-control" name="email" placeholder="Email Anda" type="text" value="<?php echo set_value('email'); ?>" />
					<span class="text-danger"><?php echo form_error('email'); ?></span>
				</div>

				<div class="form-group">
					<label for="subject">Kata Sandi</label>
					<input class="form-control" name="password" placeholder="Kata Sandi" type="password" />
					<span class="text-danger"><?php echo form_error('password'); ?></span>
				</div>

				<div class="form-group">
					<label for="subject">Kata Sandi (lagi)</label>
					<input class="form-control" name="cpassword" placeholder="Tulis kata sandi lagi" type="password" />
					<span class="text-danger"><?php echo form_error('cpassword'); ?></span>
				</div>
				<div class="form-group">
					<label for="subject">Hak Akses</label>
					<select class="form-control" name="akses"/>
						<option value="PA">Guru</option>
						<option value="Tatausaha">Tatausaha</option>
						<option value="Kepala">Kepala</option>
						<option value="BP">BP</option>
						<option value="Pengajaran">Pengajaran</option>
					</select>
					<span class="text-danger"><?php echo form_error('akses'); ?></span>
				</div>
				<div class="form-group">
					<p class="text-center"><button name="submit" type="submit" class="btn btn-primary">Daftar</button>
					<a href="<?php echo base_url();?>" class="btn btn-info">Batal</a></p>
				</div>
				<?php echo form_close(); ?>
			</div>
		</div>
</div></div></div>
</body>
</html>
