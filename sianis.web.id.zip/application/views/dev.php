<?php
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Dalam Pengembangan (Under Construction)</title>
<style type="text/css">
<!--
body { background-color:#dedede;}
#layout{margin:0px auto; width:300px; min-height:448px; margin-top:40px;}
h1.bawah{ font-family:Arial, Helvetica, sans-serif; font-size:19px; margin:0px; padding-top:0px; padding-left:30px; color:#FFF; line-height:19px; padding-bottom:10px; margin-top:20px; text-align:center; font-weight:normal;}
h1.title{ font-family:Arial, Helvetica, sans-serif; font-size:19px; margin:0px; padding-top:0px; padding-left:30px; color:#FFF; line-height:19px; padding-bottom:10px; padding-top:20px; text-align:center; font-weight:normal;}
h2{ font-family:Arial, Helvetica, sans-serif; font-size:24px; margin:0px; padding-top:10px; padding-left:30px; color:#FFF; line-height:24px; padding-bottom:10px;}
hr{
	margin-top:20px;
	margin-left:30px;
	margin-right:30px;
	margin-bottom:0px;
	color: #fff;
	background-color: #fff;
	height: 5px;
}
#top{background-image:url(images/slide_01.gif); width:300px; height:61px;}
#atas{ width:282px; min-height:380px; background:url(images/slide2_03.gif); background-repeat:repeat; margin-bottom:0px; padding:0px;}
#atas p{margin:0px; padding:0px; margin-left:15px; margin-right:15px; padding-right:15px; padding-left:15px; color:#FFF; font-family:"Lucida Sans Unicode", "Lucida Grande", sans-serif; font-size:12px; text-align:center; margin-left:32px;}
#atas p a{ color:#FF0;}
#atas ul{margin:0px; padding:0px; margin-left:45px; margin-top:5px; margin-bottom:5px;}
#atas ul li{font-family:"Lucida Sans Unicode", "Lucida Grande", sans-serif; color:#FFF; font-size:12px;}
#bawah{background-image:url(images/slide_05.gif); width:300px; height:97px;}
-->
</style>
</head>

<body>
<div id="layout">
	<div id="top"></div>
	<div id="atas">



<h1 class="title">Maaf, situs masih dalam pengembangan</h1>

<p>Jika Anda pemilik situs ini, Anda dapat mulai mengelola situs Anda
dengan login ke <a href=/cpanel>cPanel</a> untuk mengunggah file,
menginstal aplikasi web, dsb. Atau, bacalah
<a href=http://kb.masterweb.net/beta/r/Panduan_pengguna_shared_hosting>Panduan
Pengguna Shared Hosting</a> kami.</p>

<h1 class="bawah">Sorry, this website is still under construction</h1>

<p><i>If you are the owner of this website, you can start managing
your website by logging in to <a href=/cpanel>cPanel</a> control
panel to upload files, etc. Or, please consult our
<a href=http://kb.masterweb.net/beta/r/Panduan_pengguna_shared_hosting>Getting
Started Guide</a>.</i></p>

<br /><br />
  <div align=center><a href=http://www.masterweb.net/><img border=0 alt="Hosted By MWN"
  title="Hosted By MWN" src=images/mwn_small_emblem3.gif /></a></div>



    </div>
    <div id="bawah"></div>


</div>
</body>

</html>

