sed -i 's/form-group row row/form-group row/g' *.php
