<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Borang Pendaftaran Sianis</title>
	<link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="container">
<?php
if($valid == '1')
{
	echo '<div class="alert alert-success">Proses validasi surel berhasil, <a href="'.base_url().'">Lanjut</a></div>';
}
else
{
	echo '<div class="alert alert-danger">Proses validasi surel berhasil</div>';
}
; ?>
</div>
</body>
</html>
