<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
echo 'mohon bersabar, deskripsi sedang diproses. Klik kanan reload/refresh atau tekan tombol F5 kalau proses terhenti';
?>
<script>setTimeout(function () {
   window.location.href= '<?php echo base_url();?>deskripsi/<?php echo $tautan;?>/<?php echo $penilaian;?>/<?php echo $nomor;?>'; // the redirect goes here
},500);
			</script>
<?php
