<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
echo 'SELESAI';
if($asal == 'mapel')
{
	echo '<br />Tutup jendela ini. Tombol ctrl w bisa digunakan untuk menutup';
}
else
{
	?>
	<script>setTimeout(function () {
	   window.location.href= '<?php echo base_url();?>guru/nilai'; // the redirect goes here
	},1000);
		</script>
<?php
}
