    <!-- START HEADER -->
    <div id="header" class="group margin-bottom">

        <div class="group container">
            <div class="row" id="logo-headersidebar-container">
                <!-- START LOGO -->
                <div id="logo" class="span6 group">
                    <a id="logo-img" href="index.html" title="Libra">
                        <img src="<?php echo base_url();?>images/logo.png" title="Sianis" alt="Sianis" />
                    </a>
                    <p id='tagline'>Sistem Administrasi Nilai Siswa</p>
                </div>
                <!-- END LOGO -->

                <!-- START HEADER SIDEBAR -->
                <div id="header-sidebar" class="span6 group">
                    <div class="widget-first widget header-text-image">
                        <div class="text-image" style="text-align:left">
                            <img src="<?php echo base_url();?>images/phone1.png" alt="CUSTOMER SUPPORT" />
                        </div>

                        <div class="text-content">
                            <h3>CUSTOMER SUPPORT (SMS Only)</h3>
                            <p>+62 - 81212187658</p>
                        </div>
                    </div>

                    <div class="widget-last widget widget_text">
                        <div class="textwidget">
                            <div class="socials-default-small facebook-small default">
                                <a href="# " class="socials-default-small default facebook" >facebook</a>
                            </div>

                            <div class="socials-default-small skype-small default">
                                <a href="# " class="socials-default-small default skype" >skype</a>
                            </div>

                            <div class="socials-default-small linkedin-small default">
                                <a href="#" class="socials-default-small default linkedin" >linkedin</a>
                            </div>

                            <div class="socials-default-small twitter-small default">
                                <a href="#" class="socials-default-small default twitter" >twitter</a>
                            </div>

                            <div class="socials-default-small flickr-small default">
                                <a href="#" class="socials-default-small default flickr" >flickr</a>
                            </div>

                            <div class="socials-default-small rss-small default">
                                <a href="#" class="socials-default-small default rss" >rss</a>
                            </div>

                            <div class="socials-default-small pinterest-small default">
                                <a href="#" class="socials-default-small default pinterest" >pinterest</a>

                            </div>
                         </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- BEGIN FLEXSLIDER SLIDER -->
 		<div id="slider-flexslider-0" class="slider slider-flexslider flexslider container" style="">
    	   	<div class="slider-wrapper">
                <ul class="slides">
                    <li>
                    	<img width="1170" height="378" src="<?php echo base_url();?>images/slider/0013.jpg" class="attachment-full" alt="001" />
    	            </li>
                    
                    <li>
                    	<img width="1170" height="378" src="<?php echo base_url();?>images/slider/0033.jpg" class="attachment-full" alt="002" />
    	            </li>
                    
                    <li>
                    	<img width="1170" height="378" src="<?php echo base_url();?>images/slider/0034.jpg" class="attachment-full" alt="003" />
    	            </li>
                    
                    <li>
                    	<img width="1170" height="378" src="<?php echo base_url();?>images/slider/0042.jpg" class="attachment-full" alt="004" />
    	            </li>
                </ul>
            </div>
            <div class="slider-shadow"></div>
		</div>
        
 
        <script type="text/javascript">
            jQuery(document).ready(function($){
			    $('#slider-flexslider-0.flexslider .slider-wrapper').flexslider({
			        animation: 'fade',
			        slideshowSpeed: 3000,
			        animationSpeed: 800,
			        touch: false,
			        controlNav: false
			    });
            });
        </script>            
    </div>
    <!-- END HEADER -->
