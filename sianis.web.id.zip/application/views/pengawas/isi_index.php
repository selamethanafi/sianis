<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//============================================================+
// Nama Berkas 		: isi_index.php
// Lokasi      		: application/views/pengawas
// Terakhir diperbarui	: Rab 01 Jul 2015 11:53:41 WIB 
// Author      		: Selamet Hanafi
//
// (c) Copyright:
//               MAN Tengaran
//               www.mantengaran.sch.id
//               selamethanafi@yahoo.co.id
//
// License:
//    Copyright (C) 2009-2014 MAN Tengaran
//    Informasi detil ada di LISENSI.TXT 
//============================================================+
?>
<div class="container">
<div class="panel panel-default">
<div class="panel-heading"><h3><?php echo $judulhalaman;?></h3></div>
<div class="panel-body">
Assalamu alaikum wr.wb., Selamat Datang di Beranda Pengawas Madrasah
<br /><br />
<p>
Pilih tampilan klik di <a href="<?php echo base_url();?>pengawas/csstema">sini</a>
</p>

</div></div></div>
