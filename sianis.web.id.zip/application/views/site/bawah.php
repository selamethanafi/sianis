<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
?>
    <!-- START FOOTER -->
    <div id="footer">
        <div class="container">
            <div class="row">
                <div class="footer-widgets-area with-sidebar-right">
                    <div class="widget-first widget span2 widget_text"><h3>About us</h3>
                        <div class="textwidget">
                            Aliquam pellentesque pellentesque turpis, ut <a href="#">bibendum sapien</a> sollicitudin nec
                            plasiren.
                            Pellentesque posuere ornare placerat. Suspendisse potenti.
                        </div>
                    </div>

                    <div class="widget span2 widget_nav_menu">
                        <h3>A menu widget</h3>

                        <div class="menu-widget-footer-container">
                            <ul id="menu-widget-footer" class="menu">
                                <li class="menu-item menu-item-type-post_type menu-item-object-page">
                                    <a href="accordion-style.html">About</a>
                                </li>

                                <li class="menu-item menu-item-type-post_type">
                                    <a href="testimonials.html">Testimonials</a>
                                </li>

                                <li class="menu-item menu-item-type-post_type">
                                    <a href="portfolio-3-columns.html">Portfolio</a>
                                </li>

                                <li class="menu-item menu-item-type-post_type">
                                    <a href="get-in-touch.html">Get in touch</a>
                                </li>

                                <li class="menu-item menu-item-type-custom">
                                    <a href="#">Policy</a>
                                </li>

                                <li class="menu-item menu-item-type-custom">
                                    <a href="#">Utilities</a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="widget-last widget span2 widget_nav_menu">
                        <h3>Socialize</h3>

                        <div class="menu-socialize-container">
                            <ul id="menu-socialize" class="menu">

                                <li class="menu-item menu-item-type-custom">
                                    <a href="#">Facebook</a>
                                </li>

                                <li class="menu-item menu-item-type-custom">
                                    <a href="#">Twitter</a>
                                </li>

                                <li class="menu-item menu-item-type-custom">
                                    <a href="#">LinkedIn</a>
                                </li>

                                <li class="menu-item menu-item-type-custom">
                                    <a href="#">Google+</a>
                                </li>

                                <li class="menu-item menu-item-type-custom">
                                    <a href="#">Pinterest</a>
                                </li>

                                <li class="menu-item menu-item-type-custom">
                                    <a href="#">Flickr</a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="footer-widgets-sidebar with-sidebar-right">
                    <div  class="widget-first widget span6 yit_quick_contact">
                        <h3>Get in touch</h3>

                        <form class="contact-form row" method="post" action="" enctype="multipart/form-data">

                            <div class="usermessagea"></div>
                            <fieldset>
                                <ul>
                                    <li class="text-field with-icon span3">
                                        <label>
                                            <span class="mainlabel">Name</span>
                                        </label>

                                        <div class="input-prepend">
                                            <span class="add-on">
                                                <img src="<?php echo base_url();?>assets2/images/footer/author-footer.png" alt="" title=""/></span>
                                            <input type="text" name="yit_contact[name]" class="with-icon required" value=""/>
                                        </div>
                                        <div class="msg-error"></div>
                                        <div class="clear"></div>
                                    </li>

                                    <li class="text-field with-icon span3">
                                        <label>
                                            <span class="mainlabel">Email</span>
                                        </label>

                                        <div class="input-prepend">
                                            <span class="add-on">
                                                <img src="<?php echo base_url();?>assets2/images/footer/envelope-footer.png" alt="" title=""/>
                                            </span>
                                            <input type="text" name="yit_contact[email]" class="with-icon required email-validate" value=""/>
                                        </div>
                                        <div class="msg-error"></div>
                                        <div class="clear"></div>
                                    </li>

                                    <li class="textarea-field with-icon span6">
                                        <label>
                                            <span class="mainlabel">Message</span>
                                        </label>

                                        <div class="input-prepend">
                                            <span class="add-on">
                                                <img src="<?php echo base_url();?>assets2/images/footer/pencil-footer.png" alt="" title=""/>
                                            </span>
                                            <textarea name="yit_contact[message]" rows="8" cols="30" class="with-icon required"></textarea>
                                        </div>
                                        <div class="msg-error"></div>
                                        <div class="clear"></div>
                                    </li>

                                    <li class="submit-button span6">
                                        <div style="position:absolute;left:-9999px;">
                                            <input type="text" name="email_check_2" id="email_check_2" value=""/>
                                        </div>
                                        <input type="hidden" name="yit_action" value="sendemail" id="yit_action"/>
                                        <input type="hidden" name="yit_referer" value="index.html"/>
                                        <input type="hidden" name="id_form" value="228"/>
                                        <input type="submit" name="yit_sendemail" value="SEND" class="sendmail alignright"/>
                                        <div class="clear"></div>
                                    </li>
                                </ul>
                            </fieldset>
                        </form>

                        <script type="text/javascript">
                            var messages_form_228 = {
                                name: "Insert the name",
                                email: "Insert a valid email",
                                message: "Insert a message"
                            };
                        </script>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END FOOTER -->

    <!-- START COPYRIGHT -->
    <div id="copyright">
        <div class="container">
            <div class="row">
                <div class="left span6">
                    <p>
                        <a href="http://yithemes.com/"><img src="http://yithemes.com/cdn/images/various/footer_yith_grey.png" alt="Your Inspiration Themes" style="position:relative; top:9px; margin: -22px 5px 0 0;"></a>&nbsp;Copyright 2012 - <strong>Libra theme</strong> by
                        Your Inspiration Themes
                    </p>
                </div>
                <div class="right span6">
                    <p>
                        <a href="http://yithemes.com/themes/wordpress/libra-corporate-portfolio-wp-theme/?ap_id=libra-html"><strong>Download the free version for Wordpress</strong></a>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- END COPYRIGHT -->

    <div class="wrapper-border"></div>

    </div>
<!-- END WRAPPER -->

</div>
<!-- END BG SHADOW -->

<script type="text/javascript" src="<?php echo base_url();?>assets2/js/comment-reply.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/underscore.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/jquery/jquery.masonry.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/sliders/polaroid/js/jquery.polaroid.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/jquery.colorbox-min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/jquery.easing.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/jquery.flexslider-min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/jquery.carouFredSel-6.1.0-packed.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/jQuery.BlackAndWhite.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/jquery.touchSwipe.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/portfolios/slide-detail/js/jquery.filterable.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/sliders/polaroid/js/jquery.transform-0.8.0.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/sliders/polaroid/js/jquery.preloader.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/hoverIntent.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/media-upload.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/jquery.clickout.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/responsive.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/mobilemenu.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/jquery.superfish.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/jquery.placeholder.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/contact.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/jquery.tipsy.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/jquery.cycle.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/shortcodes.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets2/js/jquery.custom.js"></script>

</body>
<!-- END BODY -->
</html>
