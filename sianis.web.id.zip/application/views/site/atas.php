<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<!DOCTYPE html>
<!--[if IE 6]>
<html id="ie6" class="ie"lang="en-US">
<![endif]-->
<!--[if IE 7]>
<html id="ie7"  class="ie"lang="en-US">
<![endif]-->
<!--[if IE 8]>
<html id="ie8"  class="ie"lang="en-US">
<![endif]-->
<!--[if IE 9]>
<html id="ie9"  class="ie"lang="en-US">
<![endif]-->
<!--[if gt IE 9]>
<html class="ie"lang="en-US">
<![endif]-->

<!-- This doesn't work but i prefer to leave it here... maybe in the future the MS will support it... i hope... -->
<!--[if IE 10]>
<html id="ie10"  class="ie"lang="en-US">
<![endif]-->


<!--[if !IE]>
<html lang="en-US">
<![endif]-->

<!-- START HEAD -->
<head>
    <meta charset="UTF-8" />

    <!-- this line will appear only if the website is visited with an iPad -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.2, user-scalable=yes" />



    <title>SiANis | Sistem Administrasi Nilai Siswa</title>

    <!-- RESET STYLESHEET -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo base_url();?>assets2/css/reset.css" />
    <!-- BOOTSTRAP STYLESHEET -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo base_url();?>assets2/css/bootstrap.css" />
    <!-- MAIN THEME STYLESHEET -->
    <link rel="stylesheet" type="text/css" media="all" href="<?php echo base_url();?>assets2/style.css" />

    <!-- [favicon] begin -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>images/favicon.ico" />
    <link rel="icon" type="image/x-icon" href="<?php echo base_url();?>images/favicon.ico" />
    <!-- [favicon] end -->

    <!-- Touch icons more info: http://mathiasbynens.be/notes/touch-icons -->
    <!-- For iPad3 with retina display: -->
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="apple-touch-icon-144x.png" />
    <!-- For first- and second-generation iPad: -->
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="apple-touch-icon-114x.png" />
    <!-- For first- and second-generation iPad: -->
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="apple-touch-icon-72x.png">
    <!-- For non-Retina iPhone, iPod Touch, and Android 2.1+ devices: -->
    <link rel="apple-touch-icon-precomposed" href="apple-touch-icon-57x.png" />

    <link rel="stylesheet" id="thickbox-css"  href="<?php echo base_url();?>assets2/js/thickbox/thickbox.css" type="text/css" media="all" />
    <link rel="stylesheet" id="flexslider-css" href="<?php echo base_url();?>assets2/sliders/flexslider/css/flexslider.css" type="text/css" media="all" />
    <link rel="stylesheet" id="flex-slider-css" href="<?php echo base_url();?>assets2/sliders/flexslider/css/slider.css" type="text/css" media="all" />
    <link rel="stylesheet" id="flexslider-elegant-css" href="<?php echo base_url();?>assets2/sliders/flexslider-elegant/css/flexslider.css" type="text/css" media="all" />
    <link rel="stylesheet" id="colorbox-css" href="<?php echo base_url();?>assets2/css/colorbox.css" type="text/css" media="all" />
    <link rel="stylesheet" id="customfont1-css"  href="<?php echo base_url();?>assets2/sliders/usquare/fonts/ostrich%20sans/stylesheet.css" type="text/css" media="all" />
    <link rel="stylesheet" id="customfont2-css"  href="<?php echo base_url();?>assets2/sliders/usquare/fonts/PT%20sans/stylesheet.css" type="text/css" media="all" />
    <link rel="stylesheet" id="google-fonts-css"  href="http://fonts.googleapis.com/css?family=Playfair+Display%7COpen+Sans+Condensed%3A300%7COpen+Sans%7CShadows+Into+Light%7CMuli%7CDroid+Sans%7CArbutus+Slab%7CAbel&#038;ver=3.5.1" type="text/css" media="all" />
    <link rel="stylesheet" id="responsive-css"  href="<?php echo base_url();?>assets2/css/responsive.css" type="text/css" media="all" />
    <link rel="stylesheet" id="polaroid-slider-css"  href="<?php echo base_url();?>assets2/sliders/polaroid/css/polaroid.css" type="text/css" media="all" />
    <link rel="stylesheet" id="slide-detail-css"  href="<?php echo base_url();?>assets2/portfolios/slide-detail/css/style.css" type="text/css" media="all" />
    <link rel="stylesheet" id="ahortcodes-css"  href="<?php echo base_url();?>assets2/css/shortcodes.css" type="text/css" media="all" />
    <link rel="stylesheet" id="contact-form-css"  href="<?php echo base_url();?>assets2/css/contact_form.css" type="text/css" media="all" />
    <link rel="stylesheet" id="custom-css"  href="<?php echo base_url();?>assets2/css/custom.css" type="text/css" media="all" />

    <script type="text/javascript" src="<?php echo base_url();?>assets2/js/jquery/jquery.js"></script>



</head>
<!-- END HEAD -->
<!-- START BODY -->
<body class="home page no_js responsive stretched">

<!-- START BG SHADOW -->
<div class="bg-shadow">

<!-- START WRAPPER -->
    <div id="wrapper" class="container group">

        <!-- START TOP BAR -->
        <div id="topbar">
            <div class="container">
                <div class="row">
                    <div id="nav" class="span12 light">

                        <!-- START MAIN NAVIGATION -->

                        <ul id="menu-menu" class="level-1">
                            <li>
                                <a href="<?php echo base_url();?>">HOME</a>
                            </li>
                            <li>
                                <a href="#">FEATURES</a>
                                <ul class="sub-menu">
                                    <li><a href="services-module.html">Services Module</a></li>
                                    <li><a href="blog-modules.html">Blog modules</a></li>
                                    <li><a href="portfolio-and-video-modules.html">Portfolio and video modules</a></li>
                                    <li><a href="libra-features.html">Libra features</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="#">PORTFOLIO</a>
                                <ul class="sub-menu">
                                    <li><a href="portfolio-libra.html">Libra</a></li>
                                    <li><a href="portfolio-pinterest.html">Pinterest</a></li>
                                    <li><a href="portfolio-slide-detail.html">Slide Detail</a></li>
                                    <li><a href="portfolio-filterable.html">Filterable</a></li>
                                    <li><a href="portfolio-2-columns.html">2 Columns</a></li>
                                    <li><a href="portfolio-3-columns.html">3 Columns</a></li>
                                    <li><a href="portfolio-4-columns.html">4 Columns</a></li>
                                    <li><a href="portfolio-big-image.html">Big Image</a></li>
                                    <li><a href="portfolio-slider.html">Slider</a></li>
                                    <li><a href="portfolio-project-detail-1.html">Project Detail #1</a></li>
                                    <li><a href="portfolio-project-detail-2.html">Project detail #2</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="#">PAGES</a>
                                <ul class="sub-menu">
                                    <li>
                                        <a href="testimonials.html">Testimonials</a></li>
                                    <li>
                                        <a href="#">Blog</a>
                                        <ul class="sub-menu">
                                            <li><a href="blog-libra-big.html">Libra Big</a></li>
                                            <li><a href="blog-libra-small.html">Libra Small</a></li>
                                            <li><a href="blog-elegant.html">Elegant</a></li>
                                            <li><a href="blog-big-thumbnails.html">Big Thumbnails</a></li>
                                            <li><a href="blog-small-thumbnails.html">Small Thumbnails</a></li>
                                            <li><a href="blog-pinterest.html">Pinterest</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="pages-faq.html">FAQ</a>
                                    </li>
                                    <li>
                                        <a href="#">About</a>
                                        <ul class="sub-menu">
                                            <li><a href="accordion-style.html">Accordion Style</a></li>
                                            <li><a href="circle-style.html">Circle Style</a></li>
                                            <li><a href="u-square-style.html">U-square style</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="error-404.html">Error 404</a>
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <a href="#">SHORTCODES</a>
                                <ul class="sub-menu">
                                    <li><a href="shortcodes-alert-box-buttons.html">Alert box &amp; Buttons</a></li>
                                    <li><a href="shortcodes-charts.html">Charts</a></li>
                                    <li><a href="shortcodes-icon-section.html">Icon section</a></li>
                                    <li><a href="shortcodes-media-widgets.html">Media &amp; Widgets</a></li>
                                    <li><a href="shortcodes-mix-various.html">Mix &amp; Various</a></li>
                                    <li><a href="shortcodes-table-box-prices.html">Table &amp; Box prices</a></li>
                                    <li><a href="shortcodes-typography.html">Typography</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="#">CONTACT</a>
                                <ul class="sub-menu">
                                    <li><a href="get-in-touch.html">With MAP</a></li>
                                    <li><a href="get-in-touch-2.html">Without MAP</a></li>
                                </ul>
                            </li>
                        </ul>
                        <!-- END MAIN NAVIGATION -->

                        <!-- START TOPBAR LOGIN -->

                        <div id="topbar_login" class="not_logged_in">

                            <a class="topbar_login" href="<?php echo base_url();?>login">
                                LOGIN 
                            </a>
                        </div>
                        <!-- END TOPBAR LOGIN -->
                    </div>
                </div>
            </div>
        </div>
         <!-- END TOP BAR -->
    <!-- START HEADER -->
    <div id="header" class="group margin-bottom">

        <div class="group container">
            <div class="row" id="logo-headersidebar-container">
                <!-- START LOGO -->
                <div id="logo" class="span6 group">
                    <a id="logo-img" href="index.html" title="Libra">
                        <img src="<?php echo base_url();?>images/logo.png" title="Sianis" alt="Sianis" />
                    </a>
                    <p id='tagline'>Sistem Administrasi Nilai Siswa</p>
                </div>
                <!-- END LOGO -->

                <!-- START HEADER SIDEBAR -->
                <div id="header-sidebar" class="span6 group">
                    <div class="widget-first widget header-text-image">
                        <div class="text-image" style="text-align:left">
                            <img src="<?php echo base_url();?>images/phone1.png" alt="CUSTOMER SUPPORT" />
                        </div>

                        <div class="text-content">
                            <h3>CUSTOMER SUPPORT (SMS Only)</h3>
                            <p>+62 - 81212187658</p>
                        </div>
                    </div>

                    <div class="widget-last widget widget_text">
                        <div class="textwidget">
                            <div class="socials-default-small facebook-small default">
                                <a href="# " class="socials-default-small default facebook" >facebook</a>
                            </div>

                            <div class="socials-default-small skype-small default">
                                <a href="# " class="socials-default-small default skype" >skype</a>
                            </div>

                            <div class="socials-default-small linkedin-small default">
                                <a href="#" class="socials-default-small default linkedin" >linkedin</a>
                            </div>

                            <div class="socials-default-small twitter-small default">
                                <a href="#" class="socials-default-small default twitter" >twitter</a>
                            </div>

                            <div class="socials-default-small flickr-small default">
                                <a href="#" class="socials-default-small default flickr" >flickr</a>
                            </div>

                            <div class="socials-default-small rss-small default">
                                <a href="#" class="socials-default-small default rss" >rss</a>
                            </div>

                            <div class="socials-default-small pinterest-small default">
                                <a href="#" class="socials-default-small default pinterest" >pinterest</a>

                            </div>
                         </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END HEADER -->

