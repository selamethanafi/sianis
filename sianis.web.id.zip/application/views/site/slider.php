    <!-- START HEADER -->
    <div id="header" class="group margin-bottom">

        <div class="group container">
            <div class="row" id="logo-headersidebar-container">
                <!-- START LOGO -->
                <div id="logo" class="span6 group">
                    <a id="logo-img" href="index.html" title="Libra">
                        <img src="<?php echo base_url();?>images/logo.png" title="Sianis" alt="Sianis" />
                    </a>
                    <p id='tagline'>Sistem Administrasi Nilai Siswa</p>
                </div>
                <!-- END LOGO -->

                <!-- START HEADER SIDEBAR -->
                <div id="header-sidebar" class="span6 group">
                    <div class="widget-first widget header-text-image">
                        <div class="text-image" style="text-align:left">
                            <img src="<?php echo base_url();?>images/phone1.png" alt="CUSTOMER SUPPORT" />
                        </div>

                        <div class="text-content">
                            <h3>CUSTOMER SUPPORT (SMS Only)</h3>
                            <p>+62 - 81212187658</p>
                        </div>
                    </div>

                    <div class="widget-last widget widget_text">
                        <div class="textwidget">
                            <div class="socials-default-small facebook-small default">
                                <a href="# " class="socials-default-small default facebook" >facebook</a>
                            </div>

                            <div class="socials-default-small skype-small default">
                                <a href="# " class="socials-default-small default skype" >skype</a>
                            </div>

                            <div class="socials-default-small linkedin-small default">
                                <a href="#" class="socials-default-small default linkedin" >linkedin</a>
                            </div>

                            <div class="socials-default-small twitter-small default">
                                <a href="#" class="socials-default-small default twitter" >twitter</a>
                            </div>

                            <div class="socials-default-small flickr-small default">
                                <a href="#" class="socials-default-small default flickr" >flickr</a>
                            </div>

                            <div class="socials-default-small rss-small default">
                                <a href="#" class="socials-default-small default rss" >rss</a>
                            </div>

                            <div class="socials-default-small pinterest-small default">
                                <a href="#" class="socials-default-small default pinterest" >pinterest</a>

                            </div>
                         </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END HEADER -->
