<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//============================================================+
// Dimutakhirkan	: Kam 31 Des 2015 12:15:49 WIB 
// Nama Berkas 		: form_mencetak.php
// Lokasi      		: application/views/guru/
// Terakhir diperbarui	: Rab 01 Jul 2015 09:56:09 WIB 
// Author      		: Selamet Hanafi
//
// (c) Copyright:
//               Selamet Hanafi
//               sianis.web.id
//               selamethanafi@yahoo.co.id
//
// License:
//    Copyright (C) 2009-2014 Selamet Hanafi
//    Informasi detil ada di LISENSI.TXT 
//============================================================+
?><div class="container-fluid">
<?php
$xloc = base_url().'bimtik/formmencetak';
?>
<div class="card">
<div class="card-header"><h3><?php echo $judulhalaman;?></h3></div>
<div class="card-body">
<?php
echo '<form name="formx" method="post" action="'.$xloc.'" class="form-horizontal" role="form">';
echo '<div class="form-group row"><div class="col-sm-3"><label class="control-label">Perangkat hendak dicetak</label></div><div class="col-sm-9">';
echo "<select name=\"noyangdicetak\" onChange=\"MM_jumpMenu('self',this,0)\" class=\"form-control\">";
	echo '<option value="'.$noyangdicetak.'">'.$yangdicetak.'</option>';
	echo '<option value="'.$xloc.'/2">Blanko Nilai</option>';
	echo '<option value="'.$xloc.'/18">Daftar Nilai Pengetahuan</option>';
	echo '<option value="'.$xloc.'/19">Daftar Nilai Keterampilan</option>';
	echo '</select></div></div>';
?>
</form>
</div></div></div>
