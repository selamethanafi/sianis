<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//============================================================+
// Nama Berkas 		pembagian_tugas.php
// Lokasi      		application/views/guru/
// Author      		Selamet Hanafi
//             		  selamethanafi@yahoo.co.id
//
// (c) Copyright:
//               Sianis
//               www.sianis.web.id
//               selamet.hanafi@gmail.com
//
// License:
//    Copyright (C) 2014 Sianis
//    Informasi detil ada di LISENSI.TXT 
//============================================================+
?>
<div class="container-fluid">
	<div class="card">
	<div class="card-header"><h3><?php echo $judulhalaman;?></h3></div>
	<div class="card-body">
<?php 
if(($aksi == 'hapus') and (!empty($id_mapel)))
	{
	$this->db->query("delete from `bimtik_mapel` where `id_mapel`='$id_mapel' and `kodeguru`='$kodeguru'");
	}
	?>
<form class="form-horizontal" role="form" action="<?php echo base_url().'bimtik/pembagiantugas';?>" method="post">
	<div class="form-group row">
		<div class="col-sm-3" ><label for="thnajaran" class="control-label">Tahun Pelajaran</label></div>
		<div class="col-sm-9" ><input name="thnajaran" disabled value="<?php echo $thnajaran;?>" class="form-control"></div>
	</div>
	<div class="form-group row">
		<div class="col-sm-3" ><label for="semester" class="control-label">Semester</label></div>
		<div class="col-sm-9" ><input type="hidden" name="kode_guru" value="<?php echo $kodeguru;?>"><input name="semester" disabled value="<?php echo $semester;?>" class="form-control"></div>
	</div>
	<div class="form-group row">
		<div class="col-sm-3" ><label for="kelas" class="control-label">Kelas</label></div>
		<div class="col-sm-9" >
 			<select name="kelas" class="form-control">
				<?php
				echo '<option value=""></option>';
				$daftar_kelas = $this->db->query("SELECT * from `m_walikelas` where `thnajaran`='$thnajaran' and `semester`='$semester' order by `kelas`");
				foreach($daftar_kelas->result() as $ka)
				{
					echo "<option value='".$ka->kelas."'>".$ka->kelas."</option>";
				}
				echo '</select>';
				?>
			<p class="help-block">Hubungi pengajaran untuk mengisi daftar wali kelas kalau kelas tidak ada</p>
		</div>
	</div>
	<div class="form-group row">
		<div class="col-sm-3" ><label for="ranah" class="control-label">Ranah Penilaian</label></div>
		<div class="col-sm-9" ><select name="ranah" class="form-control">
				<?php
				echo '<option value="KP">KP</option></select>';
			?>
		</div>
	</div>
	<div class="form-group row">
		<div class="col-sm-3"><label for="jam" class="control-label">Jam Tatap Muka</label></div>
		<div class="col-sm-9" ><input type="text" name="jam" placeholder="cacah jam tatap muka" class="form-control"></div>
	</div>
	<div class="form-group row">
		<div class="col-sm-3"><label for="kkm" class="control-label">KKM</label></div>
		<div class="col-sm-9" ><input type="text" name="kkm" placeholder="kkm" class="form-control"></div>
	</div>
	<p class="text-center"><button type="submit" class="btn btn-primary">Simpan</button></p>
</form>
<?php
echo '<table class="table table-hover table-bordered table-responsive"><thead>
<tr align="center"><td><strong>No.</strong></td><td><strong>Kelas</strong></td><td><strong>Ranah</strong></td><td><strong>KKM</strong></td><td><strong>JTM</strong></td><td><strong>Hapus</strong></td></tr></thead>';
$nomor=1;
$jtm = 0;
$ta = $this->db->query("select * from `bimtik_mapel` where `thnajaran`='$thnajaran' and `semester`='$semester' and `kodeguru`='$kodeguru'");
foreach($ta->result() as $b)
{
	echo "<tbody><tr><td align='center'>".$nomor."</td><td>".$b->kelas."</td>";
		echo "<td align='center'>".$b->ranah."</td><td align='center'>".$b->kkm."</td><td align='center'>".$b->jam."</td><td  align='center'>";
		echo "<a href='".base_url()."bimtik/pembagiantugas/hapus/".$b->id_mapel."' onClick=\"return confirm('Anda yakin ingin menghapus data ".$b->thnajaran." smt ".$b->semester." kelas ".$b->kelas." mapel ".$b->mapel." ?')\" title='Hapus Pembagian Tugas'><span class='fa fa-trash-alt'></span></a>";
	echo "</td></tr></tbody>";
$nomor++;
}
?>
</table>
</div></div></div>
