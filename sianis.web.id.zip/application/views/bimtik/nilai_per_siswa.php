<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//============================================================+
// Dimutakhirkan	: Kam 31 Des 2015 12:23:28 WIB 
// Nama Berkas 		: daftarnilai.php
// Lokasi      		: application/views/bimtik/
// Author      		: Selamet Hanafi
//             		  selamethanafi@yahoo.co.id
//
// (c) Copyright:
//               Sianis
//               www.sianis.web.id
//               selamet.hanafi@gmail.com
//
// License:
//    Copyright (C) 2014 Sianis
//    Informasi detil ada di LISENSI.TXT 
//============================================================+
?>
<div class="container-fluid">
<div class="card">
<div class="card-header"><h3><?php echo $judulhalaman;?></h3></div>
<div class="card-body">
<?php
echo '<p><a href="'.base_url().'bimtik/daftarnilai/'.$id_mapel.'" class="btn btn-info">Kembali</a></p>';
//echo '<div class="alert alert-danger"><h1>Masih dalam tahap pengembangan, jangan digunakan dahulu!</h1></div>';
$jenis_deskripsi = 6;
$tmapel = $this->db->query("select * from `bimtik_mapel` where `id_mapel`='$id_mapel' and `kodeguru` = '$kodeguru'");
if($tmapel->num_rows()>0)
{
	foreach($tmapel->result() as $dtmapel)
	{
		$thnajaran = $dtmapel->thnajaran;
		$semester = $dtmapel->semester;
		$kelas = $dtmapel->kelas;
		$ranah = $dtmapel->ranah;
		$kkm = $dtmapel->kkm;
		$cacah_ulangan_harian = $dtmapel->cacah_ulangan_harian;
		$cacah_kuis = $dtmapel->nkuis;
		$nbobot_ulangan_harian = $dtmapel->bobot_ulangan_harian;
		$kkm_uh1 = $dtmapel->kkm_uh1;
		$kkm_uh2 = $dtmapel->kkm_uh2;
		$kkm_uh3 = $dtmapel->kkm_uh3;
		$kkm_uh4 = $dtmapel->kkm_uh4;
		$kkm_mid = $dtmapel->kkm_mid;
		$kkm_uas = $dtmapel->kkm_uas;
		$materi1 = $dtmapel->materi1;
		$materi2 = $dtmapel->materi2;
		$materi3 = $dtmapel->materi3;
		$materi4 = $dtmapel->materi4;
		$materi5 = $dtmapel->materi5;
		$materi6 = $dtmapel->materi6;
		$materi7 = $dtmapel->materi7;
		$materi8 = $dtmapel->materi8;
		$materi9 = $dtmapel->materi9;
		$materi10 = $dtmapel->materi10;
	}
	$te = $this->db->query("select * from siswa_kelas where `thnajaran`='$thnajaran' and `kelas` = '$kelas' and `semester`='$semester' and status='Y' order by `nis` ASC");
	$cacah_siswa = $te->num_rows();

	if($kkm_uh1 == 0)
	{
		$kkm_uh1 = $kkm;
	}
	if($kkm_uh2 == 0)
	{
		$kkm_uh2 = $kkm;
	}
	if($kkm_uh3 == 0)
	{
		$kkm_uh3 = $kkm;
	}
	if($kkm_uh4 == 0)
	{
		$kkm_uh4 = $kkm;
	}

	$kurikulum = cari_kurikulum($thnajaran,$semester,$kelas);
	if ($jenis_deskripsi==1)
	{$jenis_deskripsine = "Berdasarkan Ulangan (Deskripsi Otomatis)";
	}
	if ($jenis_deskripsi==2)
	{
		$jenis_deskripsine = "Berdasarkan Nilai Akhir (Deskripsi Otomatis)";
	}
	if ($jenis_deskripsi==5)
	{
		$jenis_deskripsine = "Berdasarkan Nilai Sekolah (Deskripsi Otomatis)";
	}
	if ($jenis_deskripsi==3)
	{
		$jenis_deskripsine = "Berdasarkan Kriteria lalu dipilih (Deskripsi Otomatis)";
	}
	if ($jenis_deskripsi==0)
	{$jenis_deskripsine = "Kopi Paste / Manual";
	}
	if ($jenis_deskripsi==6)
	{$jenis_deskripsine = "Versi Kemenag";
	}
	if ($jenis_deskripsi==4)
	{$jenis_deskripsine = "Berdasar bank deskripsi";
	}
	$nomor_urute = $nomor_urut - 1;
	$ta = $this->db->query("select * from siswa_kelas where `thnajaran`='$thnajaran' and `kelas` = '$kelas' and `semester`='$semester' and status='Y' order by `nis` ASC limit $nomor_urute,1");
	if($ta->num_rows()>0)
	{
		foreach($ta->result() as $a)
		{
			$nis = $a->nis;
		}
		?>
		<div class="col-sm-6"><label class="control-label">Tahun Pelajaran</label></div>
		<div class="col-sm-6"><p class="form-control-static"><?php echo $thnajaran;?></p></div>
		<div class="col-sm-6"><label class="control-label">Semester</label></div><div class="col-sm-6"><p class="form-control-static"><?php echo $semester;?></p></div>
		<div class="col-sm-6"><label class="control-label">Kelas</label></div><div class="col-sm-6"><p class="form-control-static"><?php echo $kelas;?></p></div>
		<div class="col-sm-6"><label class="control-label">Ranah Penilaian</label></div><div class="col-sm-6"><p class="form-control-static"><?php echo $ranah;?></div>
		<div class="col-sm-6"><label class="control-label">KKM / Cacah Ulangan Harian</label></div><div class="col-sm-6"><p class="form-control-static"><strong><?php echo $kkm;?> </strong> / <strong><?php echo $cacah_ulangan_harian;?></strong> <a href="<?php echo base_url();?>bimtik/ubahkkm/<?php echo $id_mapel;?>" title="Ubah KKM dll"><span class="fa fa-edit"></span></a></p></div>
		<div class="col-sm-6"><label class="control-label">Bobot Ulangan Harian </label></div><div class="col-sm-6"><p class="form-control-static"><?php 
		echo '<strong>'.$nbobot_ulangan_harian;?>% </strong>  <a href="<?php echo base_url();?>bimtik/ubahkkm/<?php echo $id_mapel;?>" title="Ubah KKM dll"><span class="fa fa-edit"></span></a></p></div>
		<div class="col-sm-6"><label class="control-label">Jenis Deskripsi</label></div><div class="col-sm-6"><p class="form-control-static"><?php echo $jenis_deskripsi;?> <?php echo $jenis_deskripsine;?></p></div>
		<div class="col-sm-6"><label class="control-label">Kurikulum</label></div><div class="col-sm-6"><p class="form-control-static"><?php echo $kurikulum;?></p></div>
		<div class="col-sm-6"><label class="control-label">NIS / Nama</label></div><div class="col-sm-6"><p class="form-control-static"><?php echo $nis.' / <strong>'.nis_ke_nama($nis);?></strong></p></div>
		<?php
		if($aksi == 'proses')
		{
			echo '<form name="formx" method="post" action="'.base_url().'bimtik/updatenilaipersiswa/'.$nomor_urut.'/'.$id_mapel.'" class="form-horizontal" role="form">';
			// nilai kognitif
			$tb = $this->db->query("select * from `bimtik_nilai` where `thnajaran`='$thnajaran' and `semester`='$semester' and `nis`= '$nis'");
				if($tb->num_rows() > 0)
				{
					echo '<h4>Nilai Pengetahuan</h4><h4 class="text-danger">Ulangan Harian</h4>';
					foreach($tb->result() as $b)
					{
						echo '<input type="hidden" name="kd" value="'.$b->kd.'">';
						if ($cacah_ulangan_harian == 0)
						{
							echo '<div class="form-group row"><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">UH1</span><input type="text" name="uh1" value="'.$b->nilai_uh1.'" class="form-control" readonly></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">UH2</span><input type="text" name="uh2" value="'.$b->nilai_uh2.'" class="form-control" readonly></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">UH3</span><input type="text" name="uh3" value="'.$b->nilai_uh3.'" class="form-control" readonly></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">UH4</span><input type="text" name="uh4" value="'.$b->nilai_uh4.'" class="form-control" readonly></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">UH5</span><input type="text" name="uh5" value="'.$b->nilai_uh5.'" class="form-control" readonly></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">UH6</span><input type="text" name="uh6" value="'.$b->nilai_uh6.'" class="form-control" readonly></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">UH7</span><input type="text" name="uh7" value="'.$b->nilai_uh7.'" class="form-control" readonly></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">UH8</span><input type="text" name="uh8" value="'.$b->nilai_uh8.'" class="form-control" readonly></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">UH9</span><input type="text" name="uh9" value="'.$b->nilai_uh9.'" class="form-control" readonly></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">UH10</span><input type="text" name="uh10" value="'.$b->nilai_uh10.'" class="form-control" readonly></div></div></div>';
						}
						$galat = 0;
						if ($cacah_ulangan_harian == 1)
						{
							
							if(($jenis_deskripsi == 6) or ($jenis_deskripsi == 1))
							{
								if(empty($materi1))
								{
									echo '<div class="alert alert-info">KD 1 masih kosong</div>';	
									$galat = 1;
								}
							}
							if($galat == 0)
							{
								echo '<div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi1.'</span><input type="text" name="uh1" value="'.$b->nilai_uh1.'" class="form-control"></div></div></div><input type="hidden" name="uh2" value="'.$b->nilai_uh2.'"><input type="hidden" name="uh3" value="'.$b->nilai_uh3.'"><input type="hidden" name="uh4" value="'.$b->nilai_uh4.'" ><input type="hidden" name="uh5" value="'.$b->nilai_uh5.'"><input type="hidden" name="uh6" value="'.$b->nilai_uh6.'"><input type="hidden" name="uh7" value="'.$b->nilai_uh7.'"><input type="hidden" name="uh8" value="'.$b->nilai_uh8.'"><input type="hidden" name="uh9" value="'.$b->nilai_uh9.'"><input type="hidden" name="uh10" value="'.$b->nilai_uh10.'">';
							}
						}
						if ($cacah_ulangan_harian == 2)
						{
							if(($jenis_deskripsi == 6) or ($jenis_deskripsi == 1))
							{
								if((empty($materi1)) or (empty($materi2)))
								{
									echo '<div class="alert alert-info">KD 1 atau KD 2 masih kosong</div>';	
									$galat = 1;
								}
							}
							if($galat == 0)
							{
								echo '<div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi1.'</span><input type="text" name="uh1" value="'.$b->nilai_uh1.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi2.'</span><input type="text" name="uh2" value="'.$b->nilai_uh2.'" class="form-control"></div></div></div><input type="hidden" name="uh3" value="'.$b->nilai_uh3.'"><input type="hidden" name="uh4" value="'.$b->nilai_uh4.'" ><input type="hidden" name="uh5" value="'.$b->nilai_uh5.'"><input type="hidden" name="uh6" value="'.$b->nilai_uh6.'"><input type="hidden" name="uh7" value="'.$b->nilai_uh7.'"><input type="hidden" name="uh8" value="'.$b->nilai_uh8.'"><input type="hidden" name="uh9" value="'.$b->nilai_uh9.'"><input type="hidden" name="uh10" value="'.$b->nilai_uh10.'">';
							}
						}
						if ($cacah_ulangan_harian == 3)
						{
							if(($jenis_deskripsi == 6) or ($jenis_deskripsi == 1))
							{
								if((empty($materi1)) or (empty($materi2)) or (empty($materi3)))
								{
									echo '<div class="alert alert-info">KD 1, KD 2, atau KD 3 masih kosong</div>';	
									$galat = 1;
								}
							}
							if($galat == 0)
							{
								echo '<div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi1.'</span><input type="text" name="uh1" value="'.$b->nilai_uh1.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi2.'</span><input type="text" name="uh2" value="'.$b->nilai_uh2.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH3 '.$materi3.'</span><input type="text" name="uh3" value="'.$b->nilai_uh3.'" class="form-control"></div></div></div><input type="hidden" name="uh4" value="'.$b->nilai_uh4.'" ><input type="hidden" name="uh5" value="'.$b->nilai_uh5.'"><input type="hidden" name="uh6" value="'.$b->nilai_uh6.'"><input type="hidden" name="uh7" value="'.$b->nilai_uh7.'"><input type="hidden" name="uh8" value="'.$b->nilai_uh8.'"><input type="hidden" name="uh9" value="'.$b->nilai_uh9.'"><input type="hidden" name="uh10" value="'.$b->nilai_uh10.'">';
							}
						}
						if ($cacah_ulangan_harian == 4)
						{
							if(($jenis_deskripsi == 6) or ($jenis_deskripsi == 1))
							{
								if((empty($materi1)) or (empty($materi2)) or (empty($materi3)) or (empty($materi4)))
								{
									echo '<div class="alert alert-info">KD 1, KD 2, KD 3, atau KD 4 masih kosong</div>';	
									$galat = 1;
								}
							}
							if($galat == 0)
							{
								echo '<div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi1.'</span><input type="text" name="uh1" value="'.$b->nilai_uh1.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi2.'</span><input type="text" name="uh2" value="'.$b->nilai_uh2.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH3 '.$materi3.'</span><input type="text" name="uh3" value="'.$b->nilai_uh3.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH4 '.$materi4.'</span><input type="text" name="uh4" value="'.$b->nilai_uh4.'" class="form-control"></div></div></div><input type="hidden" name="uh5" value="'.$b->nilai_uh5.'"><input type="hidden" name="uh6" value="'.$b->nilai_uh6.'"><input type="hidden" name="uh7" value="'.$b->nilai_uh7.'"><input type="hidden" name="uh8" value="'.$b->nilai_uh8.'"><input type="hidden" name="uh9" value="'.$b->nilai_uh9.'"><input type="hidden" name="uh10" value="'.$b->nilai_uh10.'">';
							}
						}
						if ($cacah_ulangan_harian == 5)
						{
							if(($jenis_deskripsi == 6) or ($jenis_deskripsi == 1))
							{
								if((empty($materi1)) or (empty($materi2)) or (empty($materi3)) or (empty($materi4)) or (empty($materi5)))
								{
									echo '<div class="alert alert-info">KD 1, KD 2, KD 3, KD 4, atau KD 5 masih kosong</div>';	
									$galat = 1;
								}
							}
							if($galat == 0)
							{
								echo '<div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi1.'</span><input type="text" name="uh1" value="'.$b->nilai_uh1.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi2.'</span><input type="text" name="uh2" value="'.$b->nilai_uh2.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH3 '.$materi3.'</span><input type="text" name="uh3" value="'.$b->nilai_uh3.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH4 '.$materi4.'</span><input type="text" name="uh4" value="'.$b->nilai_uh4.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH5 '.$materi5.'</span><input type="text" name="uh5" value="'.$b->nilai_uh5.'" class="form-control"></div></div></div><input type="hidden" name="uh6" value="'.$b->nilai_uh6.'"><input type="hidden" name="uh7" value="'.$b->nilai_uh7.'"><input type="hidden" name="uh8" value="'.$b->nilai_uh8.'"><input type="hidden" name="uh9" value="'.$b->nilai_uh9.'"><input type="hidden" name="uh10" value="'.$b->nilai_uh10.'">';
							}
						}
						if ($cacah_ulangan_harian == 6)
						{
							if(($jenis_deskripsi == 6) or ($jenis_deskripsi == 1))
							{
								if((empty($materi1)) or (empty($materi2)) or (empty($materi3)) or (empty($materi4)) or (empty($materi5)) or (empty($materi6)))
								{
									echo '<div class="alert alert-info">KD 1, KD 2, KD 3, KD 4, KD5, atau KD 6 masih kosong</div>';	
									$galat = 1;
								}
							}
							if($galat == 0)
							{
								echo '<div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi1.'</span><input type="text" name="uh1" value="'.$b->nilai_uh1.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi2.'</span><input type="text" name="uh2" value="'.$b->nilai_uh2.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH3 '.$materi3.'</span><input type="text" name="uh3" value="'.$b->nilai_uh3.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH4 '.$materi4.'</span><input type="text" name="uh4" value="'.$b->nilai_uh4.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH5 '.$materi5.'</span><input type="text" name="uh5" value="'.$b->nilai_uh5.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH6 '.$materi6.'</span><input type="text" name="uh6" value="'.$b->nilai_uh6.'" class="form-control"></div></div></div><input type="hidden" name="uh7" value="'.$b->nilai_uh7.'"><input type="hidden" name="uh8" value="'.$b->nilai_uh8.'"><input type="hidden" name="uh9" value="'.$b->nilai_uh9.'"><input type="hidden" name="uh10" value="'.$b->nilai_uh10.'">';
							}
						}
						if ($cacah_ulangan_harian == 7)
						{
							if(($jenis_deskripsi == 6) or ($jenis_deskripsi == 1))
							{
								if((empty($materi1)) or (empty($materi2)) or (empty($materi3)) or (empty($materi4)) or (empty($materi5)) or (empty($materi6)) or (empty($materi7)))
								{
									echo '<div class="alert alert-info">KD 1, KD 2, KD 3, KD 4, KD5, KD 6, KD 7, atau KD 7 masih kosong</div>';	
									$galat = 1;
								}
							}
							if($galat == 0)
							{
								echo '<div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi1.'</span><input type="text" name="uh1" value="'.$b->nilai_uh1.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi2.'</span><input type="text" name="uh2" value="'.$b->nilai_uh2.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH3 '.$materi3.'</span><input type="text" name="uh3" value="'.$b->nilai_uh3.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH4 '.$materi4.'</span><input type="text" name="uh4" value="'.$b->nilai_uh4.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH5 '.$materi5.'</span><input type="text" name="uh5" value="'.$b->nilai_uh5.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH6 '.$materi6.'</span><input type="text" name="uh6" value="'.$b->nilai_uh6.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH7 '.$materi7.'</span><input type="text" name="uh7" value="'.$b->nilai_uh7.'" class="form-control"></div></div></div><input type="hidden" name="uh8" value="'.$b->nilai_uh8.'"><input type="hidden" name="uh9" value="'.$b->nilai_uh9.'"><input type="hidden" name="uh10" value="'.$b->nilai_uh10.'">';
							}
						}
						if ($cacah_ulangan_harian == 8)
						{
							if(($jenis_deskripsi == 6) or ($jenis_deskripsi == 1))
							{
								if((empty($materi1)) or (empty($materi2)) or (empty($materi3)) or (empty($materi4)) or (empty($materi5)) or (empty($materi6)) or (empty($materi7)) or (empty($materi8)))
								{
									echo '<div class="alert alert-info">KD 1, KD 2, KD 3, KD 4, KD5, KD 6, KD 7, atau KD 8 masih kosong</div>';	
									$galat = 1;
								}
							}
							if($galat == 0)
							{
								echo '<div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi1.'</span><input type="text" name="uh1" value="'.$b->nilai_uh1.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi2.'</span><input type="text" name="uh2" value="'.$b->nilai_uh2.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH3 '.$materi3.'</span><input type="text" name="uh3" value="'.$b->nilai_uh3.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH4 '.$materi4.'</span><input type="text" name="uh4" value="'.$b->nilai_uh4.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH5 '.$materi5.'</span><input type="text" name="uh5" value="'.$b->nilai_uh5.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH6 '.$materi6.'</span><input type="text" name="uh6" value="'.$b->nilai_uh6.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH7 '.$materi7.'</span><input type="text" name="uh7" value="'.$b->nilai_uh7.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH8 '.$materi8.'</span><input type="text" name="uh8" value="'.$b->nilai_uh8.'" class="form-control"></div></div></div><input type="hidden" name="uh9" value="'.$b->nilai_uh9.'"><input type="hidden" name="uh10" value="'.$b->nilai_uh10.'">';
							}
						}
						if ($cacah_ulangan_harian == 9)
						{
							if(($jenis_deskripsi == 6) or ($jenis_deskripsi == 1))
							{
								if((empty($materi1)) or (empty($materi2)) or (empty($materi3)) or (empty($materi4)) or (empty($materi5)) or (empty($materi6)) or (empty($materi7)) or (empty($materi8)) or (empty($materi9)))
								{
									echo '<div class="alert alert-info">KD 1, KD 2, KD 3, KD 4, KD5, KD 6, KD 7, KD 8, atau KD 9 masih kosong</div>';	
									$galat = 1;
								}
							}
							if($galat == 0)
							{
								echo '<div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi1.'</span><input type="text" name="uh1" value="'.$b->nilai_uh1.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi2.'</span><input type="text" name="uh2" value="'.$b->nilai_uh2.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH3 '.$materi3.'</span><input type="text" name="uh3" value="'.$b->nilai_uh3.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH4 '.$materi4.'</span><input type="text" name="uh4" value="'.$b->nilai_uh4.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH5 '.$materi5.'</span><input type="text" name="uh5" value="'.$b->nilai_uh5.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH6 '.$materi6.'</span><input type="text" name="uh6" value="'.$b->nilai_uh6.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH7 '.$materi7.'</span><input type="text" name="uh7" value="'.$b->nilai_uh7.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH8 '.$materi8.'</span><input type="text" name="uh8" value="'.$b->nilai_uh8.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH9 '.$materi9.'</span><input type="text" name="uh9" value="'.$b->nilai_uh9.'" class="form-control"></div></div></div><input type="hidden" name="uh10" value="'.$b->nilai_uh10.'">';
							}
						}

						if ($cacah_ulangan_harian == 10)
						{
							if(($jenis_deskripsi == 6) or ($jenis_deskripsi == 1))
							{
								if((empty($materi1)) or (empty($materi2)) or (empty($materi3)) or (empty($materi4)) or (empty($materi5)) or (empty($materi6)) or (empty($materi7)) or (empty($materi8)) or (empty($materi9)) or (empty($materi10)))
								{
									echo '<div class="alert alert-info">KD 1, KD 2, KD 3, KD 4, KD5, KD 6, KD 7, KD 8, KD 9, atau KD 10 masih kosong</div>';	
									$galat = 1;
								}
							}
							if($galat == 0)
							{
								echo '<div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi1.'</span><input type="text" name="uh1" value="'.$b->nilai_uh1.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH1 '.$materi2.'</span><input type="text" name="uh2" value="'.$b->nilai_uh2.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH3 '.$materi3.'</span><input type="text" name="uh3" value="'.$b->nilai_uh3.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH4 '.$materi4.'</span><input type="text" name="uh4" value="'.$b->nilai_uh4.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH5 '.$materi5.'</span><input type="text" name="uh5" value="'.$b->nilai_uh5.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH6 '.$materi6.'</span><input type="text" name="uh6" value="'.$b->nilai_uh6.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH7 '.$materi7.'</span><input type="text" name="uh7" value="'.$b->nilai_uh7.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH8 '.$materi8.'</span><input type="text" name="uh8" value="'.$b->nilai_uh8.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH9 '.$materi9.'</span><input type="text" name="uh9" value="'.$b->nilai_uh9.'" class="form-control"></div></div></div><div class="form-group row"><div class="col-sm-12"><div class="input-group"><span class="input-group-addon">UH10 '.$materi10.'</span><input type="text" name="uh10" value="'.$b->nilai_uh10.'" class="form-control"></div></div></div>';
							}
						}

					}
				}
				echo '<h4 class="text-danger">Nilai Tugas</h4><div class="form-group row">';
				if($cacah_ulangan_harian == 4)
				{
					echo '<div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 1</span><input type="text" name="tu1" value="'.$b->nilai_tu1.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 2</span><input type="text" name="tu2" value="'.$b->nilai_tu2.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 3</span><input type="text" name="tu3" value="'.$b->nilai_tu3.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 4</span><input type="text" name="tu4" value="'.$b->nilai_tu4.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 5</span><input type="text" name="tu5" value="'.$b->nilai_tu5.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 6</span><input type="text" name="tu6" value="'.$b->nilai_tu6.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 7</span><input type="text" name="tu7" value="'.$b->nilai_tu7.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 8</span><input type="text" name="tu8" value="'.$b->nilai_tu8.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 9</span><input type="text" name="tu9" value="'.$b->nilai_tu9.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 10</span><input type="text" name="tu10" value="'.$b->nilai_tu10.'" class="form-control"></div></div>';
				}
				elseif($cacah_ulangan_harian == 1)
				{
					echo '<div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 1</span><input type="text" name="tu1" value="'.$b->nilai_tu1.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 2</span><input type="text" value="'.$b->nilai_tu2.'" class="form-control" disabled></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 3</span><input type="text" value="'.$b->nilai_tu3.'" class="form-control" disabled></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 4</span><input type="text" value="'.$b->nilai_tu4.'" class="form-control" disabled></div></div><input type="hidden" name="tu2" value="'.$b->nilai_tu2.'"><input type="hidden" name="tu3" value="'.$b->nilai_tu3.'"><input type="hidden" name="tu4" value="'.$b->nilai_tu4.'"><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 5</span><input type="text" name="tu5" value="'.$b->nilai_tu5.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 6</span><input type="text" name="tu6" value="'.$b->nilai_tu6.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 7</span><input type="text" name="tu7" value="'.$b->nilai_tu7.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 8</span><input type="text" name="tu8" value="'.$b->nilai_tu8.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 9</span><input type="text" name="tu9" value="'.$b->nilai_tu9.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 10</span><input type="text" name="tu10" value="'.$b->nilai_tu10.'" class="form-control"></div></div>';
				}
				elseif($cacah_ulangan_harian == 2)
				{
					echo '<div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 1</span><input type="text" name="tu1" value="'.$b->nilai_tu1.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 2</span><input type="text" name="tu2" value="'.$b->nilai_tu2.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 3</span><input type="text" value="'.$b->nilai_tu3.'" class="form-control" disabled></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 4</span><input type="text"  value="'.$b->nilai_tu4.'" class="form-control" disabled></div></div><input type="hidden" name="tu3" value="'.$b->nilai_tu3.'"><input type="hidden" name="tu4" value="'.$b->nilai_tu4.'"><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 5</span><input type="text" name="tu5" value="'.$b->nilai_tu5.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 6</span><input type="text" name="tu6" value="'.$b->nilai_tu6.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 7</span><input type="text" name="tu7" value="'.$b->nilai_tu7.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 8</span><input type="text" name="tu8" value="'.$b->nilai_tu8.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 9</span><input type="text" name="tu9" value="'.$b->nilai_tu9.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 10</span><input type="text" name="tu10" value="'.$b->nilai_tu10.'" class="form-control"></div></div>';
				}
				elseif($cacah_ulangan_harian == 3)
				{
					echo '<div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 1</span><input type="text" name="tu1" value="'.$b->nilai_tu1.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 2</span><input type="text" name="tu2" value="'.$b->nilai_tu2.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 3</span><input type="text" name="tu3" value="'.$b->nilai_tu3.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 4</span><input type="text" value="'.$b->nilai_tu4.'" class="form-control" disabled></div></div><input type="hidden" name="tu4" value="'.$b->nilai_tu4.'"><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 5</span><input type="text" name="tu5" value="'.$b->nilai_tu5.'" class="form-control" disabled></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 6</span><input type="text" name="tu6" value="'.$b->nilai_tu6.'" class="form-control" disabled></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 7</span><input type="text" name="tu7" value="'.$b->nilai_tu7.'" class="form-control" disabled></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 8</span><input type="text" name="tu8" value="'.$b->nilai_tu8.'" class="form-control" disabled></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 9</span><input type="text" name="tu9" value="'.$b->nilai_tu9.'" class="form-control" disabled></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 10</span><input type="text" name="tu10" value="'.$b->nilai_tu10.'" class="form-control" disabled></div></div>';
				}
				elseif($cacah_ulangan_harian == 3)
				{
					echo '<div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 1</span><input type="text" name="tu1" value="'.$b->nilai_tu1.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 2</span><input type="text" name="tu2" value="'.$b->nilai_tu2.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 3</span><input type="text" name="tu3" value="'.$b->nilai_tu3.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 4</span><input type="text" value="'.$b->nilai_tu4.'" class="form-control" disabled></div></div><input type="hidden" name="tu4" value="'.$b->nilai_tu4.'"><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 5</span><input type="text" name="tu5" value="'.$b->nilai_tu5.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 6</span><input type="text" name="tu6" value="'.$b->nilai_tu6.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 7</span><input type="text" name="tu7" value="'.$b->nilai_tu7.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 8</span><input type="text" name="tu8" value="'.$b->nilai_tu8.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 9</span><input type="text" name="tu9" value="'.$b->nilai_tu9.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 10</span><input type="text" name="tu10" value="'.$b->nilai_tu10.'" class="form-control"></div></div>';
				}
				else
				{
					echo '<div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 1</span><input type="text" name="tu1" value="'.$b->nilai_tu1.'" class="form-control" readonly></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 2</span><input type="text" name="tu2" value="'.$b->nilai_tu2.'" class="form-control" readonly></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 3</span><input type="text" name="tu3" value="'.$b->nilai_tu3.'" class="form-control" readonly></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 4</span><input type="text" name="tu4" value="'.$b->nilai_tu4.'" class="form-control" readonly></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 5</span><input type="text" name="tu5" value="'.$b->nilai_tu5.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 6</span><input type="text" name="tu6" value="'.$b->nilai_tu6.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 7</span><input type="text" name="tu7" value="'.$b->nilai_tu7.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 8</span><input type="text" name="tu8" value="'.$b->nilai_tu8.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 9</span><input type="text" name="tu9" value="'.$b->nilai_tu9.'" class="form-control"></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Tugas 10</span><input type="text" name="tu10" value="'.$b->nilai_tu10.'" class="form-control"></div></div>';
				}
				echo '</div>';
				if($cacah_ulangan_harian > 0)
				{
					$ruh = ($b->nilai_uh1 + $b->nilai_uh2 + $b->nilai_uh3 + $b->nilai_uh4 + $b->nilai_uh5 + $b->nilai_uh6 + $b->nilai_uh7 + $b->nilai_uh8 + $b->nilai_uh9 + $b->nilai_uh10) / $cacah_ulangan_harian;
				}
				else
				{
					$ruh = 0;
				}
				if($cacah_ulangan_harian > 0)
				{
					$rtu = ($b->nilai_tu1 + $b->nilai_tu2 + $b->nilai_tu3 + $b->nilai_tu4) / $cacah_ulangan_harian;
				}
				else
				{
					$rtu = 0;
				}
				$nilai_rapor = ($rtu +$ruh )/2;
				echo '<h4 class="text-danger">Perhitungan Rapor</h4><div class="form-group row">
					<div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Pengetahun '.$ruh.'</span></div></div><div class="col-sm-2"><div class="input-group"><span class="input-group-addon">Keterampilan '.$rtu.'</span></div></div></div>';
				echo '</div>';

			echo '<p class="text-center"><input type="submit" value="Simpan" class="btn btn-primary"></p></form>';
		}
		else
		{

			$this->db->query("delete from `deskripsi_capaian_nilai` where `id_mapel` = '$id_mapel' and `nis`='$nis'");
			if($nomor_urut == 1)
			{
				$next = $nomor_urut + 1;
				echo '<p class="text-center"><a href="'.base_url().'bimtik/nilaipersiswa/'.$nomor_urut.'/'.$id_mapel.'/proses" class="btn btn-success">Nilai Lagi</a> <a href="'.base_url().'bimtik/nilaipersiswa/'.$next.'/'.$id_mapel.'/proses" class="btn btn-info">Siswa berikutnya</a></p>';
			}
			if(($nomor_urut > 1) and ($nomor_urut < $cacah_siswa))
			{
				$next = $nomor_urut + 1;
				$prev = $nomor_urut - 1;
				echo '<p class="text-center"> <a href="'.base_url().'bimtik/nilaipersiswa/'.$prev.'/'.$id_mapel.'/proses" class="btn btn-danger">Siswa sebelumnya</a> <a href="'.base_url().'bimtik/nilaipersiswa/'.$nomor_urut.'/'.$id_mapel.'/proses" class="btn btn-success">Nilai Lagi</a> <a href="'.base_url().'bimtik/nilaipersiswa/'.$next.'/'.$id_mapel.'/proses" class="btn btn-info">Siswa berikutnya</a></p>';
			}
			if($nomor_urut == $cacah_siswa)
			{
				$prev = $nomor_urut - 1;
				echo '<p class="text-center"> <a href="'.base_url().'bimtik/nilaipersiswa/'.$prev.'/'.$id_mapel.'/proses" class="btn btn-danger">Siswa sebelumnya</a> <a href="'.base_url().'bimtik/nilaipersiswa/'.$nomor_urut.'/'.$id_mapel.'/proses" class="btn btn-success">Nilai Lagi</a></p>';
			}

			$tb = $this->db->query("select * from `bimtik_nilai` where `thnajaran`='$thnajaran' and `semester`='$semester' and `nis`= '$nis'");
			foreach($tb->result() as $b)
			{
				if (($jenis_deskripsi == 1) or ($jenis_deskripsi == 6))
				{
					for($i=1;$i<=$cacah_ulangan_harian;$i++)
					{
						if($i == 1)
						{ $kkme = $kkm_uh3;}
						elseif($i == 2)
						{ $kkme = $kkm_uh3;}
						elseif($i == 3)
						{ $kkme = $kkm_uh3;}
						elseif($i == 4)
						{ $kkme = $kkm_uh4;}
						else
						{ $kkme = $kkm;}
						$field = 'nilai_uh'.$i;
						$materike = 'materi'.$i;
						$nilai = $b->$field;
						if($nilai < $kkme)
						{
							$in2["positif"] = 0;
						}
						else
						{
							$in2["positif"] = 1;
						}
						$in2["nis"] = $nis;
						$in2["id_mapel"] = $id_mapel;
						$in2["materi"] = $$materike;
						$in2["nomor_materi"] = $i;
						if($jenis_deskripsi == 1)
						{
							$in2["ket"] = deskripsi_nilai($nilai);
						}
						if($jenis_deskripsi == 6)
						{
							$in2["ket"] = deskripsi_nilai_2015($nilai,$kkm);
						}
						$this->bimtik->Simpan_Capaian_Kompetensi($in2);
					}
					$ket_tuntas='Sudah kompeten';
					if ($b->nilai_nr<$kkm)
					{$ket_tuntas = 'Belum kompeten';
					}

				} // jenis deskripsi
				$tb = $this->db->query("select * from `bimtik_nilai` where `thnajaran`='$thnajaran' and `semester`='$semester' and `nis`= '$nis'");
				foreach($tb->result() as $b)
				{
					echo '<table class="table table-striped table-hover table-bordered"><tr align="center"><td>Ulangan</td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td></tr><tr align="center"><td>KKM</td><td>'.$kkm_uh1.'</td><td>'.$kkm_uh2.'</td><td>'.$kkm_uh3.'</td><td>'.$kkm_uh4.'</td><td>'.$kkm.'</td><td>'.$kkm.'</td><td>'.$kkm.'</td><td>'.$kkm.'</td><td>'.$kkm.'</td><td>'.$kkm.'</td></tr><tr align="center"><td>Nilai</td><td>';
					if($b->nilai_uh1>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_uh1.'</div>';
					}
					elseif($b->nilai_uh1>=$kkm_uh1)
					{
						echo '<p class="text-center text-success">'.$b->nilai_uh1.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_uh1.'</div>';
					}
					echo '</td><td>';
					if($b->nilai_uh2>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_uh2.'</div>';
					}
					elseif($b->nilai_uh2>=$kkm_uh2)
					{
						echo '<p class="text-center text-success">'.$b->nilai_uh2.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_uh2.'</div>';
					}
					echo '</td><td>';
					if($b->nilai_uh3>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_uh3.'</div>';
					}
					elseif($b->nilai_uh3>=$kkm_uh3)
					{
						echo '<p class="text-center text-success">'.$b->nilai_uh3.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_uh3.'</div>';
					}
					echo '</td><td>';
					if($b->nilai_uh4>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_uh4.'</div>';
					}
					elseif($b->nilai_uh4>=$kkm_uh4)
					{
						echo '<p class="text-center text-success">'.$b->nilai_uh4.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_uh4.'</div>';
					}
					echo '</td><td>';
					if($b->nilai_uh5>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_uh5.'</div>';
					}
					elseif($b->nilai_uh5>=$kkm)
					{
						echo '<p class="text-center text-success">'.$b->nilai_uh5.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_uh5.'</div>';
					}
					echo '</td><td>';
					if($b->nilai_uh6>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_uh6.'</div>';
					}
					elseif($b->nilai_uh6>=$kkm)
					{
						echo '<p class="text-center text-success">'.$b->nilai_uh6.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_uh6.'</div>';
					}
					echo '</td><td>';
					if($b->nilai_uh7>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_uh7.'</div>';
					}
					elseif($b->nilai_uh7>=$kkm)
					{
						echo '<p class="text-center text-success">'.$b->nilai_uh7.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_uh7.'</div>';
					}
					echo '</td><td>';
					if($b->nilai_uh8>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_uh8.'</div>';
					}
					elseif($b->nilai_uh8>=$kkm)
					{
						echo '<p class="text-center text-success">'.$b->nilai_uh8.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_uh8.'</div>';
					}
					echo '</td><td>';
					if($b->nilai_uh9>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_uh9.'</div>';
					}
					elseif($b->nilai_uh9>=$kkm)
					{
						echo '<p class="text-center text-success">'.$b->nilai_uh9.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_uh9.'</div>';
					}
					echo '</td><td>';
					if($b->nilai_uh10>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_uh10.'</div>';
					}
					elseif($b->nilai_uh10>=$kkm)
					{
						echo '<p class="text-center text-success">'.$b->nilai_uh10.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_uh10.'</div>';
					}
					echo '</td></tr></table>';
			echo '<table class="table table-striped table-hover table-bordered"><tr align="center"><td>Keterampilan<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td></tr><tr align="center"><td>Nilai</td><td>';
					if($b->nilai_tu1>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_tu1.'</div>';
					}
					elseif($b->nilai_tu1>=$kkm)
					{
						echo '<p class="text-center text-success">'.$b->nilai_tu1.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_tu1.'</div>';
					}
					echo '</td><td>';
					if($b->nilai_tu2>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_tu2.'</div>';
					}
					elseif($b->nilai_tu2>=$kkm)
					{
						echo '<p class="text-center text-success">'.$b->nilai_tu2.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_tu2.'</div>';
					}
					echo '</td><td>';
					if($b->nilai_tu3>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_tu3.'</div>';
					}
					elseif($b->nilai_tu3>=$kkm)
					{
						echo '<p class="text-center text-success">'.$b->nilai_tu3.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_tu3.'</div>';
					}
					echo '</td><td>';
					if($b->nilai_tu4>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_tu4.'</div>';
					}
					elseif($b->nilai_tu4>=$kkm)
					{
						echo '<p class="text-center text-success">'.$b->nilai_tu4.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_tu4.'</div>';
					}
					echo '</td><td>';
					if($b->nilai_tu5>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_tu5.'</div>';
					}
					elseif($b->nilai_tu5>=$kkm)
					{
						echo '<p class="text-center text-success">'.$b->nilai_tu5.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_tu5.'</div>';
					}
					echo '</td><td>';

					if($b->nilai_tu6>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_tu6.'</div>';
					}
					elseif($b->nilai_tu6>=$kkm)
					{
						echo '<p class="text-center text-success">'.$b->nilai_tu6.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_tu6.'</div>';
					}
					echo '</td><td>';
					if($b->nilai_tu7>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_tu7.'</div>';
					}
					elseif($b->nilai_tu7>=$kkm)
					{
						echo '<p class="text-center text-success">'.$b->nilai_tu7.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_tu7.'</div>';
					}
					echo '</td><td>';
					if($b->nilai_tu8>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_tu8.'</div>';
					}
					elseif($b->nilai_tu8>=$kkm)
					{
						echo '<p class="text-center text-success">'.$b->nilai_tu8.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_tu8.'</div>';
					}
					echo '</td><td>';
					if($b->nilai_tu9>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_tu9.'</div>';
					}
					elseif($b->nilai_tu9>=$kkm)
					{
						echo '<p class="text-center text-success">'.$b->nilai_tu9.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_tu9.'</div>';
					}
					echo '</td><td>';
					if($b->nilai_tu10>100)
					{
						echo '<div class="alert alert-danger text-center">'.$b->nilai_tu10.'</div>';
					}
					elseif($b->nilai_tu10>=$kkm)
					{
						echo '<p class="text-center text-success">'.$b->nilai_tu10.'</p>';			
					}
					else
					{
						echo '<div class="alert alert-warning">'.$b->nilai_tu10.'</div>';
					}
					echo '</td></tr></table>';
					echo '<h2>Nilai Rapor</h2>';
					if($b->nilai_na>100)
					{
						echo '<h2 class="text-danger">Pengetahuan : '.$b->nilai_na.'</h2>';
					}
					elseif($b->nilai_na>=$kkm)
					{
						echo '<h2 class="text-success">Pengetahuan : '.$b->nilai_na.'</h2>';
					}
					else
					{
						echo '<h2 class="text-warning">Pengetahuan : '.$b->nilai_na.'</h2>';
					}
					if($b->nilai_tu>100)
					{
						echo '<h2 class="text-danger">Keterampilan : '.$b->nilai_tu.'</h2>';
					}
					elseif($b->nilai_tu>=$kkm)
					{
						echo '<h2 class="text-success">Keterampilan : '.$b->nilai_tu.'</h2>';
					}
					else
					{
						echo '<h2 class="text-warning">Keterampilan : '.$b->nilai_tu.'</h2>';
					}

				} // datar nilai
			}
		}
	}
	
}
else
{
	echo '<div class="alert alert-info"><h2>Data tidak ditemukan</h2></div>';
}

?>
</div></div></div>
