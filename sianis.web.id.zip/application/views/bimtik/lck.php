<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//============================================================+
// Nama Berkas 		: lck.php
// Lokasi      		: application/views/bimtik/
// Author      		: Selamet Hanafi
//
// (c) Copyright:
//               Sianis
//               www.sianis.web.id
//               selamethanafi@yahoo.co.id
//
// License:
//    Copyright (C) 2009-2014 Sianis
//    Informasi detil ada di LISENSI.TXT 
//============================================================+
?>
<?php
$jenis_deskripsi = 0;
$jenis_deskripsine = '';
$tingkat = '';
$tmapel = $this->db->query("select * from `bimtik_mapel` where `id_mapel`='$id_mapel'");
foreach($tmapel->result() as $dtmapel)
{
	$jenis_deskripsi = 6;
	$materi1 = $dtmapel->materi1;
	$materi2 = $dtmapel->materi2;
	$materi3 = $dtmapel->materi3;
	$materi4 = $dtmapel->materi4;
	$materi5 = $dtmapel->materi5;
	$materi6 = $dtmapel->materi6;
	$materi7 = $dtmapel->materi7;
	$materi8 = $dtmapel->materi8;
	$materi9 = $dtmapel->materi9;
	$materi10 = $dtmapel->materi10;
	$batas1 = $dtmapel->batas1;
	$batas2 = $dtmapel->batas2;
	$batas3 = $dtmapel->batas3;
	$batas4 = $dtmapel->batas4;
	$batas5 = $dtmapel->batas5;
	$batas6 = $dtmapel->batas6;
	$kelas =$dtmapel->kelas;
}
$tingkat = kelas_jadi_tingkat($kelas);
$ranah = 'KP';
?>
<div class="container-fluid">
<div class="card">
<div class="card-header"><h3><?php echo $judulhalaman;?></h3></div>
<div class="card-body">
<p><a href="<?php echo base_url(); ?>bimtik/nilai" class="btn btn-info"><span class="glyphicon glyphicon-arrow-left"></span> <b>Kelas Lain</b></a> </p>
<?php
$jenis_deskripsine = "Versi Kemenag";
if(count($query->result())>0)
{
	?>
	<div class="form-group row"><div class="col-sm-3"><label class="control-label">Tahun Pelajaran</label></div><div class="col-sm-9"><p class="form-control-static"><?php echo $thnajaran?></p></div></div>
	<div class="form-group row"><div class="col-sm-3"><label class="control-label">Semester</label></div><div class="col-sm-9"><p class="form-control-static"><?php echo $semester;?></p></div></div>
	<div class="form-group row"><div class="col-sm-3"><label class="control-label">Kelas</label></div><div class="col-sm-9"><p class="form-control-static"><?php echo $kelas;?></p></div></div>
	<div class="form-group row"><div class="col-sm-3"><label class="control-label">Ranah Penilaian</label></div><div class="col-sm-9"><p class="form-control-static"><?php echo $ranah;?></p></div></div>
	<div class="form-group row"><div class="col-sm-3"><label class="control-label">KKM</label></div><div class="col-sm-9"><p class="form-control-static"><?php echo $kkm;?></p></div></div>
	<div class="form-group row"><div class="col-sm-3"><label class="control-label">Jenis Deskripsi</label></div><div class="col-sm-9"><p class="form-control-static"><?php echo $jenis_deskripsi.' '.$jenis_deskripsine; ?></p></div></div>
	<div class="form-group row"><div class="col-sm-3"><label class="control-label">Kurikulum</label></div><div class="col-sm-9"><p class="form-control-static"><?php echo $kurikulum;?></p></div></div>
	<?php
	echo '<p>Untuk memperbarui deskripsi pengetahuan, klik <a href="'.base_url().'bimtik/statusketuntasan/'.$id_mapel.'"  class="btn btn-primary">Perbarui Deskripsi Pengetahuan</a></p>';
	$k1 = 25;
	$k2 = 150;
	$k345678 = 150;
	$k91011121314 = 150;
	$k34 = 100;
	$k5 = 100;
	$k15 = 100;
	$k6 = 100;
	$k910 = 100;
	$k11 = 100;
	$k12 = 100;
	echo '<div class="table-responsive">
		<table class="table table-hover table-striped table-bordered"><tr align="center"><td><strong>No.</strong></td><td><strong>Nama</strong></td>';
	echo '<td><strong>Nilai Pengetahuan</strong></td><td><strong>Nilai Keterampilan</strong></td><td><strong>Nilai Rapor</strong></td><td><strong>Ketuntasan</strong></td><td><strong>Deskripsi</strong></td></tr>';
	$nomor=1;
	$ta = $this->db->query("select * from `siswa_kelas` where `thnajaran`='$thnajaran' and `semester`='$semester' and `kelas`='$kelas' and `status`='Y' order by no_urut ");
	foreach($ta->result() as $a)
	{
		$nis = $a->nis;
		$namasiswa = nis_ke_nama($nis);
		$nilai_nr = '?';
		$id_nilai = '';
		$tf = $this->db->query("select * from `bimtik_nilai` where `thnajaran`='$thnajaran' and `semester`='$semester' and `nis`= '$nis' and status='Y'");
		if($tf->num_rows() > 0)
		{
			echo '<tr><td align="center">'.$nomor.'</td><td>'.$namasiswa.'</td>';
			foreach($tf->result() as $t)
			{
				$ket = substr($t->ket,0,5);
				if($ket == 'Belum')
				{
					$ket = '<p class="text-danger">Belum</p>';
				}
				else
				{
					$ket = '<p class="text-success">Sudah</p>';
				}
			}
			echo '<td align="center">'.$t->nilai_na.'</td><td align="center">'.$t->nilai_tu.'</td><td align="center">'.$t->nilai_nr.'</td><td align="center">'.$ket.'</td><td>'.$t->keterangan.'</td>';
			echo '</tr>';
		}
	$nomor++;	
	} //kalau ada

	echo '</table></div>';


}
else
{
	echo "Belum ada daftar nilai";
}


?>
</div></div></div>
