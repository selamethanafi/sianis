<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//============================================================+
// Nama Berkas 		: status_ketuntasan.php
// Lokasi      		: application/views/guru
// Author      		: Selamet Hanafi
//             		  selamethanafi@yahoo.co.id
//
// (c) Copyright:
//               Selamet Hanafi
//               sianis.web.id
//               selamet.hanafi@gmail.com
//
// License:
//    Copyright (C) 2014 Selamet Hanafi
//    Informasi detil ada di LISENSI.TXT 
//============================================================+
?>
<div class="container-fluid">
<div class="card">
<div class="card-header"><h3><?php echo $judulhalaman;?></h3></div>
<div class="card-body">
<?php
echo '<h2 class="text-warning">Mohon perhatian, pastikan penilaian keterampilan sudah diselesaikan lebih dahulu!</h2>';
echo '<h2>Mohon bersabar</h2>';
$desk = '';
if($jenis_deskripsi== 0)
{
	$id = $total_siswa + 1;
}
if(($id <= $total_siswa) and ($total_siswa > 0))
{
	$persen = $id/$total_siswa * 100;
	$persen = round($persen);
	echo '<div class="progress progress-striped active">
		<div class="progress-bar progress-bar-success" style="width:'.$persen.'%;">
		'.$id.' dari '.$total_siswa.' siswa ('.$persen.'%) terproses
		</div>
	      </div>';
	//echo 'Persentase '.$persen;
	$ta = $this->db->query("select * from bimtik_nilai where thnajaran='$thnajaran' and kelas='$kelas' and semester='$semester' and status='Y' limit $id,1");
	foreach($ta->result() as $a)
	{
		$nis = $a->nis;
		$kd = $a->kd;
		$nilai_na = $a->nilai_na;
		$nilai_tu = $a->nilai_tu;
		$nilai_nr = $a->nilai_nr;
		$ket_akhir = 'Belum kompeten';
		if($nilai_nr < $kkm)
		{
			$k1 = 0;

		}
		else
		{
			$k1 = 1;

		}
		if($k1 == 1)
		{
			$ket_akhir = 'Sudah kompeten';
		}
		$kurikulum = cari_kurikulum($thnajaran,$semester,$kelas);
		if(($jenis_deskripsi==1) or ($jenis_deskripsi==3) or ($jenis_deskripsi==6))
		{
			$td = $this->db->query("select * from `bimtik_deskripsi_capaian_nilai` where `id_mapel`='$id_mapel' and nis='$nis' and `positif`='1' order by nis ASC,ket ASC");
			$ket = '';
			$des1 = '';
			$des2 = '';
			$materine1='';
			$materine2='';
			$deske='';
			foreach($td->result() as $d)
			{
				$kete = $d->ket;
				if ($ket != $kete)
				{
				$ket = $kete;
				if (empty($des1))
					{
					$des1 .= $kete." ".$d->materi;
					}
					else
					{
					$des1 .= ", ".$kete." ".$d->materi;
					}

				} 
				else
				{
					if (empty($des1))
					{
					$des1 .= $d->materi;
					}
					else
					{
					$des1 .= ", ".$d->materi;
					}
				}
				if (empty($materine1))
				{
					$materine1 .= $d->materi;
				}
				else
				{
				$materine1 .= ", ".$d->materi;
				}
				if (empty($deske))
				{
					$deske .= $d->ket." ".$d->materi;
				}
				else
				{
					$deske .= ", ".$d->ket." ".$d->materi;
				}

			}
			$desk = $des1;	
			$ket = '';
			$td = $this->db->query("select * from `bimtik_deskripsi_capaian_nilai` where `id_mapel`='$id_mapel' and `nis` = '$nis' and `positif`='0' order by nis ASC,ket ASC");
			foreach($td->result() as $d)
			{
				$kete = $d->ket;
				if ($ket != $kete)
				{
					$ket = $kete;
					if (empty($des2))
					{
					$des2 .= $ket." ".$d->materi;
					}
					else
					{
					$des2 .= ", ".$ket." ".$d->materi;
					}

				} 
				else
				{
					if (empty($des2))
					{
						$des2 .= $d->materi;
					}
					else
					{
						$des2 .= ", ".$d->materi;
					}
				}

			}
			if (empty($desk))
			{
				$desk = $des2;	
			}
			else
			{
				if (!empty($des2))
				{
				$desk .= ", ".$des2;	
				}
			}
			if($jenis_deskripsi == 6)
			{
				if(!empty($des1))
				{
					$desk = 'Ananda '.$desk;
				}
				else
				{
					$desk = ucfirst($desk);
				}
			}
			else
			{
				$desk = ucfirst($desk);
			}
			if($jenis_deskripsi==6)
			{
				$ket26 = '????';
				if($kurikulum == '2015')
				{
					if($nilai_nr < $kkm)
					{
						$ket26 = 'belum tuntas';
					}
					else
					{
						$ket26 = 'sudah tuntas';
					}
				}
				elseif($kurikulum == '2013')
				{
					if($nilai_nr < $kkm)
					{
						$ket26 = 'belum tuntas';
					}
					else
					{
						$ket26 = 'sudah tuntas';
					}
				}
				else
				{
					if($ket_akhir == 'Belum kompeten')
					{
						$ket26 = 'belum tuntas';
					}
					else
					{
						$ket26 = 'sudah tuntas';
					}
				}
				if($nilai_nr > 84)
				{
					$predikatkog = 'sangat baik';
				}
				elseif($nilai_nr >= $kkm)
				{
					$predikatkog = 'baik';
				}
				else
				{
					$predikatkog = 'cukup';
				}
				$desk = 'Capaian kompetensi '.$ket26.' dengan predikat '.$predikatkog.'. '.$desk;
			}
			$desk = nopetik($desk);
			$this->db->query("update `bimtik_nilai` set `ket` = '$ket_akhir', `keterangan`='$desk' where `kd`='$kd'");
		} // akhir jeni 1, 3, 6
	}
	$id++;
	?>
	<script>setTimeout(function () {
		   window.location.href= '<?php echo base_url();?>bimtik/statusketuntasan/<?php echo $id_mapel?>/<?php echo $id?>';
		},1);
			</script>
	<?php
}
else
{
	$persen = 100;
	echo '<div class="progress progress-striped active">
		<div class="progress-bar progress-bar-success" style="width:'.$persen.'%;">
		'.$persen.'% terproses
		</div>
	      </div>';
	?>
	<h3>tunggu sampai berpindah halaman</h3>
	<script>setTimeout(function () {
		   window.location.href= '<?php echo base_url();?>bimtik/lck2/<?php echo $id_mapel;?>';
		},100);
			</script>
		<?php
}
?>
</div></div></div>
