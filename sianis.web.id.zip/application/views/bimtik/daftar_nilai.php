<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//============================================================+
// Dimutakhirkan	: Kam 31 Des 2015 12:23:28 WIB 
// Nama Berkas 		: daftarnilai.php
// Lokasi      		: application/views/bimtik/
// Author      		: Selamet Hanafi
//             		  selamethanafi@yahoo.co.id
//
// (c) Copyright:
//               Sianis
//               www.sianis.web.id
//               selamet.hanafi@gmail.com
//
// License:
//    Copyright (C) 2014 Sianis
//    Informasi detil ada di LISENSI.TXT 
//============================================================+
?>
<?php
$jenis_deskripsi = 6;
$tmapel = $this->db->query("select * from `bimtik_mapel` where `id_mapel`='$id_mapel'");
$jenis_deskripsine = "Versi Kemenag";
$query = $this->db->query("select * from `bimtik_nilai` where `thnajaran`='$thnajaran' and `semester`='$semester' and `kelas`='$kelas' and `status`='Y' order by `no_urut`");
?>
<div class="container-fluid">
<h2><?php echo $judulhalaman;?></h2>
<a href="javascript:;"  onClick="window.open('<?php echo base_url();?>bimtik/hapus/<?php echo $id_mapel;?>/mapel','yes','scrollbars=yes,width=550,height=400')"  class='btn btn-danger'> HAPUS DESKRIPSI</a>&nbsp;&nbsp;&nbsp;&nbsp;
<?php
echo '<a href="'.base_url().'bimtik/statusketuntasan/'.$id_mapel.'" class="btn btn-success"><b>PROSES DESKRIPSI RAPOR</b></a></p> ';
?>
<form class="form-horizontal" role="form">
<div class="form-group row"><div class="col-sm-5"><label class="control-label">Tahun Pelajaran</label></div><div class="col-sm-7"><p class="form-control-static"><?php echo $thnajaran;?></div></div>
<div class="form-group row"><div class="col-sm-5"><label class="control-label">Semester</label></div><div class="col-sm-7"><p class="form-control-static"><?php echo $semester;?></div></div>
<div class="form-group row"><div class="col-sm-5"><label class="control-label">Kelas</label></div><div class="col-sm-7"><p class="form-control-static"><?php echo $kelas;?></div></div>
<div class="form-group row"><div class="col-sm-5"><label class="control-label">Ranah Penilaian</label></div><div class="col-sm-7"><p class="form-control-static"><?php echo $ranah;?></div></div>
<div class="form-group row"><div class="col-sm-5"><label class="control-label">KKM / Cacah Ulangan Harian</label></div><div class="col-sm-7"><p class="form-control-static"><strong><?php echo $kkm;?> </strong> / <strong><?php echo $cacah_ulangan_harian;?></strong> <a href="<?php echo base_url();?>bimtik/ubahkkm/<?php echo $id_mapel;?>" title="Ubah KKM dll"><span class="fa fa-edit"></span></a></div></div>
<div class="form-group row"><div class="col-sm-5"><label class="control-label">Jenis Deskripsi</label></div><div class="col-sm-7"><p class="form-control-static"><?php echo $jenis_deskripsi;?> <?php echo $jenis_deskripsine;?></div></div>
<div class="form-group row"><div class="col-sm-5"><label class="control-label">Kurikulum</label></div><div class="col-sm-7"><p class="form-control-static"><?php echo $kurikulum;?></div></div>
</form>
<?php
	echo '<div class="alert alert-warning">Bila menentukan jenis deskripsi ini setelah mengisi nilai (nilai sudah ada), maka semua nilai harus dikirim ulang. Klik UH1/KD1 lalu klik tombol Simpan, berikutnya Klik UH2/KD2 lalu klik tombol Simpan, dst.</div>';
?>
<div class="table-responsive">
<table class="table table-striped table-hover table-bordered"><thead>
<tr align="center"><td><strong>No</strong></td><td><strong>Nama</strong></td>
<?php
if($kkm_uh1 == 0)
	{
	$kkm_uh1 = $kkm;
	}
if($kkm_uh2 == 0)
	{
	$kkm_uh2 = $kkm;
	}
if($kkm_uh3 == 0)
	{
	$kkm_uh3 = $kkm;
	}
if($kkm_uh4 == 0)
	{
	$kkm_uh4 = $kkm;
	}
if($kkm_mid == 0)
	{
	$kkm_mid = $kkm;
	}
if($kkm_uas == 0)
	{
	$kkm_uas = $kkm;
	}

if ($cacah_ulangan_harian>0)
{
	if(empty($materi1))
	{
		echo '<td>KD masih kosong</td>';
	}
	else
	{
		echo '<td colspan="2"><a href="'.base_url().'bimtik/nilaiharian/'.$id_mapel.'/1" title="Ubah Nilai KD '.$materi1.'"><strong>KD1</strong></a></td>';
	}
}
if ($cacah_ulangan_harian>1)
{
	if(empty($materi2))
	{
		echo '<td colspan="2">KD masih kosong</td>';
	}
	else
	{
		echo '<td colspan="2"><a href="'.base_url().'bimtik/nilaiharian/'.$id_mapel.'/2" title="Ubah Nilai KD '.$materi2.'"><strong>KD2</strong></a></td>';
	}
}
if ($cacah_ulangan_harian>2)
{
	if(empty($materi3))
	{
		echo '<td colspan="2">KD masih kosong</td>';
	}
	else
	{
		echo '<td colspan="2"><a href="'.base_url().'bimtik/nilaiharian/'.$id_mapel.'/3" title="Ubah Nilai KD '.$materi3.'"><strong>KD3</strong></a></td>';
	}
}
if ($cacah_ulangan_harian>3)
{
	if(empty($materi4))
	{
		echo '<td colspan="2">KD masih kosong</td>';
	}
	else
	{
		echo '<td colspan="2"><a href="'.base_url().'bimtik/nilaiharian/'.$id_mapel.'/4" title="Ubah Nilai KD '.$materi4.'"><strong>KD4</strong></a></td>';
	}
}
if ($cacah_ulangan_harian>4)
{
	if(empty($materi5))
	{
		echo '<td colspan="2">KD masih kosong</td>';
	}
	else
	{
		echo '<td colspan="2"><a href="'.base_url().'bimtik/nilaiharian/'.$id_mapel.'/5" title="Ubah Nilai KD '.$materi5.'"><strong>KD5</strong></a></td>';
	}
}
if ($cacah_ulangan_harian>5)
{
	if(empty($materi6))
	{
		echo '<td colspan="2">KD masih kosong</td>';
	}
	else
	{
	echo '<td colspan="2"><a href="'.base_url().'bimtik/nilaiharian/'.$id_mapel.'/6" title="Ubah Nilai KD '.$materi6.'"><strong>KD6</strong></a></td>';
	}
}
if ($cacah_ulangan_harian>6)
{
	if(empty($materi7))
	{
		echo '<td colspan="2">KD masih kosong</td>';
	}
	else
	{
		echo '<td colspan="2"><a href="'.base_url().'bimtik/nilaiharian/'.$id_mapel.'/7" title="Ubah Nilai KD '.$materi7.'"><strong>KD7</strong></a></td>';
	}
}
if ($cacah_ulangan_harian>7)
{
	if(empty($materi8))
	{
		echo '<td colspan="2">KD masih kosong</td>';
	}
	else
	{
		echo '<td colspan="2"><a href="'.base_url().'bimtik/nilaiharian/'.$id_mapel.'/8" title="Ubah Nilai KD '.$materi8.'"><strong>KD8</strong></a></td>';
	}
}
if ($cacah_ulangan_harian>8)
{
	if(empty($materi9))
	{
		echo '<td colspan="2">KD masih kosong</td>';
	}
	else
	{
		echo '<td colspan="2"><a href="'.base_url().'bimtik/nilaiharian/'.$id_mapel.'/9" title="Ubah Nilai KD '.$materi9.'"><strong>KD9</strong></a></td>';
	}
}
if ($cacah_ulangan_harian>9)
{
	if(empty($materi10))
	{
		echo '<td colspan="2">KD masih kosong</td>';
	}
	else
	{
		echo '<td colspan="2"><a href="'.base_url().'bimtik/nilaiharian/'.$id_mapel.'/10" title="Ubah Nilai KD '.$materi10.'"><strong>KD10</strong></a></td>';
	}
}
echo '<td><strong>Nilai Pengetahuan</strong></td>';
echo '<td><strong>Nilai Keterampilan</strong></td><td><strong>Nilai Akhir</strong></td><td><strong>Tuntas</strong></td></tr>';
?>
</thead>
<?php
$nomor=1;
$rata_nilai_uh1= 0;
$rata_nilai_uh2= 0;
$rata_nilai_uh3= 0;
$rata_nilai_uh4= 0;
$rata_nilai_tu1= 0;
$rata_nilai_tu2= 0;
$rata_nilai_tu3= 0;
$rata_nilai_tu4= 0;
$rata_nilai_na= 0;
$rata_nilai_nr= 0;
$cacah_di_bawah_kkm_uh1= 0;
$cacah_di_bawah_kkm_uh2= 0;
$cacah_di_bawah_kkm_uh3= 0;
$cacah_di_bawah_kkm_uh4= 0;
$cacah_di_bawah_kkm_mid= 0;
$cacah_di_bawah_kkm_uas= 0;
$cacah_di_bawah_kkm_na= 0;
$cacah_di_bawah_kkm_nr= 0;

$tertinggi_nilai_uh1= 0;
$tertinggi_nilai_uh2= 0;
$tertinggi_nilai_uh3= 0;
$tertinggi_nilai_uh4= 0;
$tertinggi_nilai_tu1= 0;
$tertinggi_nilai_tu2= 0;
$tertinggi_nilai_tu3= 0;
$tertinggi_nilai_tu4= 0;
$tertinggi_nilai_na= 0;
$tertinggi_nilai_nr= 0;
$terendah_nilai_uh1= 101;
$terendah_nilai_uh2= 101;
$terendah_nilai_uh3= 101;
$terendah_nilai_uh4= 101;
$terendah_nilai_tu1= 101;
$terendah_nilai_tu2= 101;
$terendah_nilai_tu3= 101;
$terendah_nilai_tu4= 101;
$terendah_nilai_na= 101;
$terendah_nilai_nr= 101;
$cacahsiswa = $query->num_rows();
if(count($query->result())>0)
{
	foreach($query->result() as $t)
	{
		$nis = $t->nis;
		$namasiswa = nis_ke_nama($nis);
	echo '<tr><td align="center">'.$nomor.'</td><td><a href="'.base_url().'bimtik/nilaipersiswa/'.$nomor.'/'.$id_mapel.'/proses">'.$namasiswa.'</a></td>';
		if($cacah_ulangan_harian>0)
		{
			if($t->nilai_uh1>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_uh1.'</td>';
			}
			if($t->nilai_tu1>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_tu1.'</td>';
			}

		}
		if($cacah_ulangan_harian>1)
		{
			if($t->nilai_uh2>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_uh2.'</td>';
			}
			if($t->nilai_tu2>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_tu2.'</td>';
			}

		}
		if($cacah_ulangan_harian>2)
		{
			if($t->nilai_uh3>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_uh3.'</td>';
			}
			if($t->nilai_tu3>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_tu3.'</td>';
			}

		}
		if($cacah_ulangan_harian>3)
		{
			if($t->nilai_uh4>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_uh4.'</td>';
			}
			if($t->nilai_tu4>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_tu4.'</td>';
			}

		}
		if($cacah_ulangan_harian>4)
		{
			if($t->nilai_uh5>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_uh5.'</td>';
			}
			if($t->nilai_tu5>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_tu5.'</td>';
			}


		}
		if($cacah_ulangan_harian>5)
		{
			if($t->nilai_uh6>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_uh6.'</td>';
			}
			if($t->nilai_tu6>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_tu6.'</td>';
			}

		}
		if($cacah_ulangan_harian>6)
		{
			if($t->nilai_uh7>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_uh7.'</td>';
			}
			if($t->nilai_tu7>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_tu7.'</td>';
			}

		}
		if($cacah_ulangan_harian>7)
		{
			if($t->nilai_uh8>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_uh8.'</td>';
			}
		}
		if($cacah_ulangan_harian>8)
		{
			if($t->nilai_uh9>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_uh9.'</td>';
			}
			if($t->nilai_tu9>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_tu9.'</td>';
			}

		}
		if($cacah_ulangan_harian>9)
		{
			if($t->nilai_uh10>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_uh10.'</td>';
			}
			if($t->nilai_tu10>100)
			{
				echo '<td align="center">lebih dari 100</td>';
			}
			else
			{
				echo '<td align="center">'.$t->nilai_tu10.'</td>';
			}

		}
	echo '<td align="center">'.round($t->nilai_na,2).'</td><td align="center">'.round($t->nilai_tu,2).'</td><td align="center">'.round($t->nilai_nr,2).'</td>';
	if($t->nilai_nr<$kkm)
	{
		echo '<td align="center"><p class="text-center text-danger">belum</p></td>';
	}
	else
	{
		echo '<td align="center"><p class="text-center text-success">sudah</p></td>';
	}
	echo '</tr>';
	if ($t->nilai_uh1 < $kkm_uh1)
		{
		$cacah_di_bawah_kkm_uh1++;
		}
	if ($t->nilai_uh2 < $kkm_uh2)
		{
		$cacah_di_bawah_kkm_uh2++;
		}
	if ($t->nilai_uh3 < $kkm_uh3)
		{
		$cacah_di_bawah_kkm_uh3++;
		}
	if ($t->nilai_uh4 < $kkm_uh4)
		{
		$cacah_di_bawah_kkm_uh4++;
		}
	if ($t->nilai_na < $kkm)
		{$cacah_di_bawah_kkm_na++;
		}
	if ($t->nilai_nr < $kkm)
		{
		$cacah_di_bawah_kkm_nr++;
		}
	if ($tertinggi_nilai_uh1 < $t->nilai_uh1)
		{$tertinggi_nilai_uh1 = $t->nilai_uh1;}
	if ($tertinggi_nilai_uh2 < $t->nilai_uh2)
		{$tertinggi_nilai_uh2 = $t->nilai_uh2;}
	if ($tertinggi_nilai_uh3 < $t->nilai_uh3)
		{$tertinggi_nilai_uh3 = $t->nilai_uh3;}
	if ($tertinggi_nilai_uh4 < $t->nilai_uh4)
		{$tertinggi_nilai_uh4 = $t->nilai_uh4;}
	if ($tertinggi_nilai_tu1 < $t->nilai_tu1)
		{$tertinggi_nilai_tu1 = $t->nilai_tu1;}
	if ($tertinggi_nilai_tu2 < $t->nilai_tu2)
		{$tertinggi_nilai_tu2 = $t->nilai_tu2;}
	if ($tertinggi_nilai_tu3 < $t->nilai_tu3)
		{$tertinggi_nilai_tu3 = $t->nilai_tu3;}
	if ($tertinggi_nilai_tu4 < $t->nilai_tu4)
		{$tertinggi_nilai_tu4 = $t->nilai_tu4;}
	if ($tertinggi_nilai_na < $t->nilai_na)
		{$tertinggi_nilai_na = $t->nilai_na;}
	if ($tertinggi_nilai_nr < $t->nilai_nr)
		{$tertinggi_nilai_nr = $t->nilai_nr;}
	if ($terendah_nilai_uh1 > $t->nilai_uh1)
		{$terendah_nilai_uh1 = $t->nilai_uh1;}
	if ($terendah_nilai_uh2 > $t->nilai_uh2)
		{$terendah_nilai_uh2 = $t->nilai_uh2;}
	if ($terendah_nilai_uh3 > $t->nilai_uh3)
		{$terendah_nilai_uh3 = $t->nilai_uh3;}
	if ($terendah_nilai_uh4 > $t->nilai_uh4)
		{$terendah_nilai_uh4 = $t->nilai_uh4;}
	if ($terendah_nilai_tu1 > $t->nilai_tu1)
		{$terendah_nilai_tu1 = $t->nilai_tu1;}
	if ($terendah_nilai_tu2 > $t->nilai_tu2)
		{$terendah_nilai_tu2 = $t->nilai_tu2;}
	if ($terendah_nilai_tu3 > $t->nilai_tu3)
		{$terendah_nilai_tu3 = $t->nilai_tu3;}
	if ($terendah_nilai_tu4 > $t->nilai_tu4)
		{$terendah_nilai_tu4 = $t->nilai_tu4;}
	if ($terendah_nilai_na > $t->nilai_na)
		{$terendah_nilai_na = $t->nilai_na;}
	if ($terendah_nilai_nr > $t->nilai_nr)
		{$terendah_nilai_nr = $t->nilai_nr;}

	$rata_nilai_uh1= $rata_nilai_uh1 + $t->nilai_uh1 ;
	$rata_nilai_uh2= $rata_nilai_uh2 + $t->nilai_uh2 ;
	$rata_nilai_uh3= $rata_nilai_uh3 + $t->nilai_uh3 ;
	$rata_nilai_uh4= $rata_nilai_uh4 + $t->nilai_uh4 ;
	$rata_nilai_tu1= $rata_nilai_tu1 + $t->nilai_tu1 ;
	$rata_nilai_tu2= $rata_nilai_tu2 + $t->nilai_tu2 ;
	$rata_nilai_tu3= $rata_nilai_tu3 + $t->nilai_tu3 ;
	$rata_nilai_tu4= $rata_nilai_tu4 + $t->nilai_tu4 ;
	$rata_nilai_na= $rata_nilai_na + $t->nilai_na ;
	$rata_nilai_nr= $rata_nilai_nr + $t->nilai_nr ;
	$nomor++;	
	}
$jmlsiswa = $nomor-1;
$rata_nilai_uh1= $rata_nilai_uh1 / $jmlsiswa;
$rata_nilai_uh2= $rata_nilai_uh2 / $jmlsiswa;
$rata_nilai_uh3= $rata_nilai_uh3 / $jmlsiswa;
$rata_nilai_uh4= $rata_nilai_uh4 / $jmlsiswa;
$rata_nilai_tu1= $rata_nilai_tu1 / $jmlsiswa;
$rata_nilai_tu2= $rata_nilai_tu2 / $jmlsiswa;
$rata_nilai_tu3= $rata_nilai_tu3 / $jmlsiswa;
$rata_nilai_tu4= $rata_nilai_tu4 / $jmlsiswa;
$rata_nilai_na= $rata_nilai_na / $jmlsiswa;
$rata_nilai_nr= $rata_nilai_nr / $jmlsiswa;
//kkm
if ($kurikulum == '2013')
	{
	}
	else
	{
	echo '<tr><td align="center"></td><td>KKM</td>';
	if($cacah_ulangan_harian>0)
		{
		echo '<td align="center">'.$kkm_uh1.'</td>';
		}
	if($cacah_ulangan_harian>1)
		{
		echo '<td align="center">'.$kkm_uh2.'</td>';
		}
	if($cacah_ulangan_harian>2)
		{
		echo '<td align="center">'.$kkm_uh3.'</td>';
		}
	if($cacah_ulangan_harian>3)
		{
		echo '<td align="center">'.$kkm_uh4.'</td>';
		}
		if($cacah_ulangan_harian>4)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>5)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>6)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>7)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>8)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>9)
		{
			echo '<td align="center"></td>';
		}
		echo '<td align="center"></td><td></td></tr>';
	}
// rata - rata
if ($kurikulum == '2013')
	{
	}
	else
	{
echo '<tr><td align="center"></td><td>Rata - rata</td>';
		if($cacah_ulangan_harian>0)
		{
		echo '<td align="center">'.round($rata_nilai_uh1, 2).'</td>';
		}
		if($cacah_ulangan_harian>1)
		{
		echo '<td align="center">'.round($rata_nilai_uh2, 2).'</td>';
		}
		if($cacah_ulangan_harian>2)
		{
		echo '<td align="center">'.round($rata_nilai_uh3, 2).'</td>';}
		if($cacah_ulangan_harian>3)
		{
		echo '<td align="center">'.round($rata_nilai_uh4, 2).'</td>';}
		if($cacah_ulangan_harian>4)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>5)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>6)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>7)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>8)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>9)
		{
			echo '<td align="center"></td>';
		}
		echo '<td align="center">'.round($rata_nilai_na, 2).'</td><td></td></tr>';

	}
//simpangan baku
	$xi_uh1=0;
	$xi_uh2=0;
	$xi_uh3=0;
	$xi_uh4=0;
	$xi_ruh=0;
	$xi_tu1=0;
	$xi_tu2=0;
	$xi_tu3=0;
	$xi_tu4=0;
	$xi_rtu=0;
	$xi_mid=0;
	$xi_uas=0;
	$xi_na= 0;
	$xi_nr= 0;
	foreach($query->result() as $t)
	{
	$x_uh1= $rata_nilai_uh1 - $t->nilai_uh1 ;
	$x_uh2= $rata_nilai_uh2 - $t->nilai_uh2 ;
	$x_uh3= $rata_nilai_uh3 - $t->nilai_uh3 ;
	$x_uh4= $rata_nilai_uh4 - $t->nilai_uh4 ;
	$x_tu1= $rata_nilai_tu1 - $t->nilai_tu1 ;
	$x_tu2= $rata_nilai_tu2 - $t->nilai_tu2 ;
	$x_tu3= $rata_nilai_tu3 - $t->nilai_tu3 ;
	$x_tu4= $rata_nilai_tu4 - $t->nilai_tu4 ;
	$x_na= $rata_nilai_na - $t->nilai_na ;
	$x_nr= $rata_nilai_nr - $t->nilai_nr ;

	$xx_uh1= $x_uh1 * $x_uh1 ;
	$xx_uh2= $x_uh2 * $x_uh2 ;
	$xx_uh3= $x_uh3 * $x_uh3 ;
	$xx_uh4= $x_uh4 * $x_uh4 ;
	$xx_tu1= $x_tu1 * $x_tu1 ;
	$xx_tu2= $x_tu2 * $x_tu2 ;
	$xx_tu3= $x_tu3 * $x_tu3 ;
	$xx_tu4= $x_tu4 * $x_tu4 ;
	$xx_na= $x_na * $x_na ;
	$xx_nr= $x_nr * $x_nr ;

	$xi_uh1= $xi_uh1 + $xx_uh1 ;
	$xi_uh2= $xi_uh2 + $xx_uh2 ;
	$xi_uh3= $xi_uh3 + $xx_uh3 ;
	$xi_uh4= $xi_uh4 + $xx_uh4 ;
	$xi_tu1= $xi_tu1 + $xx_tu1 ;
	$xi_tu2= $xi_tu2 + $xx_tu2 ;
	$xi_tu3= $xi_tu3 + $xx_tu3 ;
	$xi_tu4= $xi_tu4 + $xx_tu4 ;
	$xi_na= $xi_na + $xx_na ;
	$xi_nr= $xi_nr + $xx_nr ;
	$nomor++;	
	}
	$xi_uh1= $xi_uh1 / $jmlsiswa;
	$xi_uh2= $xi_uh2 / $jmlsiswa;
	$xi_uh3= $xi_uh3 / $jmlsiswa;
	$xi_uh4= $xi_uh4 / $jmlsiswa;
	$xi_ruh= $xi_ruh / $jmlsiswa;
	$xi_tu1= $xi_tu1 / $jmlsiswa;
	$xi_tu2= $xi_tu2 / $jmlsiswa;
	$xi_tu3= $xi_tu3 / $jmlsiswa;
	$xi_tu4= $xi_tu4 / $jmlsiswa;
	$xi_rtu= $xi_rtu / $jmlsiswa;
	$xi_mid= $xi_mid / $jmlsiswa;
	$xi_uas= $xi_uas / $jmlsiswa;
	$xi_na= $xi_na / $jmlsiswa;
	$xi_nr= $xi_nr / $jmlsiswa;

	$xi_uh1= sqrt($xi_uh1);
	$xi_uh2= sqrt($xi_uh2);
	$xi_uh3= sqrt($xi_uh3);
	$xi_uh4= sqrt($xi_uh4);
	$xi_ruh= sqrt($xi_ruh);
	$xi_tu1= sqrt($xi_tu1);
	$xi_tu2= sqrt($xi_tu2);
	$xi_tu3= sqrt($xi_tu3);
	$xi_tu4= sqrt($xi_tu4);
	$xi_rtu= sqrt($xi_rtu);
	$xi_mid= sqrt($xi_mid);
	$xi_uas= sqrt($xi_uas);
	$xi_na= sqrt($xi_na);
	$xi_nr= sqrt($xi_nr);
if ($kurikulum == '2013')
	{
	}
	else
	{
echo '<tr><td align="center"></td><td>Simpangan Baku</td>';
		if($cacah_ulangan_harian>0)
		{
		echo '<td align="center">'.round($xi_uh1, 2).'</td>';}
		if($cacah_ulangan_harian>1)
		{
		echo '<td align="center">'.round($xi_uh2, 2).'</td>';}
		if($cacah_ulangan_harian>2)
		{
		echo '<td align="center">'.round($xi_uh3, 2).'</td>';}
		if($cacah_ulangan_harian>3)
		{
		echo '<td align="center">'.round($xi_uh4, 2).'</td>';}
		if($cacah_ulangan_harian>4)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>5)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>6)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>7)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>8)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>9)
		{
			echo '<td align="center"></td>';
		}
		echo '<td align="center">'.round($xi_na, 2).'</td><td></td></tr>';
	}
if ($kurikulum == '2013')
	{
	}
	else
	{
echo '<tr><td align="center"></td><td>Nilai Tertinggi</td>';
		if ($cacah_ulangan_harian>0)
		{echo '<td align="center">'.$tertinggi_nilai_uh1.'</td>';}
		if ($cacah_ulangan_harian>1)
		{echo '<td align="center">'.$tertinggi_nilai_uh2.'</td>';}
		if ($cacah_ulangan_harian>2)
		{echo '<td align="center">'.$tertinggi_nilai_uh3.'</td>';}
		if ($cacah_ulangan_harian>3)
		{echo '<td align="center">'.$tertinggi_nilai_uh4.'</td>';}
		if($cacah_ulangan_harian>4)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>5)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>6)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>7)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>8)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>9)
		{
			echo '<td align="center"></td>';
		}
		echo '<td align="center">'.$tertinggi_nilai_na.'</td><td></td></tr>';
	}

if ($kurikulum == '2013')
	{
	}
	else
	{
echo '<tr><td align="center"></td><td>Nilai terendah</td>';
		if ($cacah_ulangan_harian>0)
		{echo '<td align="center">'.$terendah_nilai_uh1.'</td>';}
		if ($cacah_ulangan_harian>1)
		{echo '<td align="center">'.$terendah_nilai_uh2.'</td>';}
		if ($cacah_ulangan_harian>2)
		{echo '<td align="center">'.$terendah_nilai_uh3.'</td>';}
		if ($cacah_ulangan_harian>3)
		{echo '<td align="center">'.$terendah_nilai_uh4.'</td>';}
		if($cacah_ulangan_harian>4)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>5)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>6)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>7)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>8)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>9)
		{
			echo '<td align="center"></td>';
		}
		echo '<td align="center">'.$terendah_nilai_na.'</td><td></td></tr>';
	}

$klasikal1='';
$klasikal2='';
$klasikal3='';
$klasikal4='';
$klasikal5='';
$klasikal6='';
$klasikal7='';
$klasikal8='';
$cacah_di_atas_kkm_uh1 = $cacahsiswa - $cacah_di_bawah_kkm_uh1;
$cacah_di_atas_kkm_uh2 = $cacahsiswa - $cacah_di_bawah_kkm_uh2;
$cacah_di_atas_kkm_uh3 = $cacahsiswa - $cacah_di_bawah_kkm_uh3;
$cacah_di_atas_kkm_uh4 = $cacahsiswa - $cacah_di_bawah_kkm_uh4;
$cacah_di_atas_kkm_mid = $cacahsiswa - $cacah_di_bawah_kkm_mid;
$cacah_di_atas_kkm_uas = $cacahsiswa - $cacah_di_bawah_kkm_uas;
$cacah_di_atas_kkm_na = $cacahsiswa - $cacah_di_bawah_kkm_na;
$cacah_di_atas_kkm_nr = $cacahsiswa - $cacah_di_bawah_kkm_nr;
$persentase_di_atas_kkm_uh1 = $cacah_di_atas_kkm_uh1 * 100 / $cacahsiswa;
$persentase_di_atas_kkm_uh2 = $cacah_di_atas_kkm_uh2 * 100 / $cacahsiswa;
$persentase_di_atas_kkm_uh3 = $cacah_di_atas_kkm_uh3 * 100 / $cacahsiswa;
$persentase_di_atas_kkm_uh4 = $cacah_di_atas_kkm_uh4 * 100 / $cacahsiswa;
$persentase_di_atas_kkm_mid = $cacah_di_atas_kkm_mid * 100 / $cacahsiswa;
$persentase_di_atas_kkm_uas = $cacah_di_atas_kkm_uas * 100 / $cacahsiswa;
$persentase_di_atas_kkm_na = $cacah_di_atas_kkm_na * 100 / $cacahsiswa;
$persentase_di_atas_kkm_nr = $cacah_di_atas_kkm_nr * 100 / $cacahsiswa;
if ($rata_nilai_uh1 > 0 )
	 {
	if ($persentase_di_atas_kkm_uh1 < $this->config->item('persentase_klasikal'))
		{
		$klasikal1='Y';
		}
		else
		{
		$klasikal1='T';
		}
	}
if ($rata_nilai_uh2 > 0 )
	 {
	if ($persentase_di_atas_kkm_uh2 < $this->config->item('persentase_klasikal'))
		{
		$klasikal2='Y';
		}
		else
		{
		$klasikal2='T';
		}
	}
if ($rata_nilai_uh3 > 0 )
	 {
	if ($persentase_di_atas_kkm_uh3 < $this->config->item('persentase_klasikal'))
		{
		$klasikal3='Y';
		}
		else
		{
		$klasikal3='T';
		}
	}
if ($rata_nilai_uh4 > 0 )
	 {
	if ($persentase_di_atas_kkm_uh4<$this->config->item('persentase_klasikal'))
		{
		$klasikal4='Y';
		}
		else
		{
		$klasikal4='T';
		}
	}
	echo '<tr><td align="center"></td><td>Klasikal *</td>';
	if($cacah_ulangan_harian>0)
	{
	echo '<td align="center">'.$klasikal1.'</td>';
	}
	if($cacah_ulangan_harian>1)
	{
	echo '<td align="center">'.$klasikal2.'</td>';
	}
	if($cacah_ulangan_harian>2)
	{
	echo '<td align="center">'.$klasikal3.'</td>';
	}
	if($cacah_ulangan_harian>3)
	{
	echo '<td align="center">'.$klasikal4.'</td>';
	}
		if($cacah_ulangan_harian>4)
		{
			echo '<td align="center">5</td>';
		}
		if($cacah_ulangan_harian>5)
		{
			echo '<td align="center">6</td>';
		}
		if($cacah_ulangan_harian>6)
		{
			echo '<td align="center">7</td>';
		}
		if($cacah_ulangan_harian>7)
		{
			echo '<td align="center">8</td>';
		}
		if($cacah_ulangan_harian>8)
		{
			echo '<td align="center">9</td>';
		}
		if($cacah_ulangan_harian>9)
		{
			echo '<td align="center">10</td>';
		}

	echo '<td align="center">'.$klasikal5.'5</td><td align="center">'.$klasikal6.'</td></tr>';
echo '<tr><td align="center"></td><td>Pengembalian Hasil Ulangan</td>';
if ($cacah_ulangan_harian>0)
{echo '<td align="center"><a href="'.base_url().'bimtik/bpu/'.$id_mapel.'/uh1" title="Pengembalian Hasil UH1" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>1)
{echo '<td align="center"><a href="'.base_url().'bimtik/bpu/'.$id_mapel.'/uh2" title="Pengembalian Hasil UH2" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>2)
{echo '<td align="center"><a href="'.base_url().'bimtik/bpu/'.$id_mapel.'/uh3" title="Pengembalian Hasil UH3" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>3)
{echo '<td align="center"><a href="'.base_url().'bimtik/bpu/'.$id_mapel.'/uh4" title="Pengembalian Hasil UH4" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>4)
{echo '<td align="center"><a href="'.base_url().'bimtik/bpu/'.$id_mapel.'/uh5" title="Pengembalian Hasil UH5" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>5)
{echo '<td align="center"><a href="'.base_url().'bimtik/bpu/'.$id_mapel.'/uh6" title="Pengembalian Hasil UH6" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>6)
{echo '<td align="center"><a href="'.base_url().'bimtik/bpu/'.$id_mapel.'/uh7" title="Pengembalian Hasil UH7" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>7)
{echo '<td align="center"><a href="'.base_url().'bimtik/bpu/'.$id_mapel.'/uh8" title="Pengembalian Hasil UH8" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>8)
{echo '<td align="center"><a href="'.base_url().'bimtik/bpu/'.$id_mapel.'/uh9" title="Pengembalian Hasil UH9" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>9)
{echo '<td align="center"><a href="'.base_url().'bimtik/bpu/'.$id_mapel.'/uh10" title="Pengembalian Hasil UH10" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
echo '</tr>';
echo '<tr><td align="center"></td><td>Analisis</td>';
if ($cacah_ulangan_harian>0)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisis/'.$id_mapel.'/uh1" title="Analisis UH1"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>1)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisis/'.$id_mapel.'/uh2" title="Analisis UH2"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>2)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisis/'.$id_mapel.'/uh3" title="Analisis UH3"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>3)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisis/'.$id_mapel.'/uh4" title="Analisis UH4"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>4)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisis/'.$id_mapel.'/uh5" title="Analisis UH5" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>5)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisis/'.$id_mapel.'/uh6" title="Analisis UH6" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>6)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisis/'.$id_mapel.'/uh7" title="Analisis UH7" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>7)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisis/'.$id_mapel.'/uh8" title="Analisis UH8" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>8)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisis/'.$id_mapel.'/uh9" title="Analisis UH9" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>9)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisis/'.$id_mapel.'/uh10" title="Analisis UH10" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
echo '</tr>';

echo '<tr><td align="center"></td><td>Analisis Jawaban Siswa</td>';
if ($cacah_ulangan_harian>0)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisisjawabansiswa/'.$id_mapel.'/uh1" title="Analisis Jawaban Siswa UH1"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>1)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisisjawabansiswa/'.$id_mapel.'/uh2" title="Analisis Jawaban Siswa UH2"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>2)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisisjawabansiswa/'.$id_mapel.'/uh3" title="Analisis Jawaban Siswa UH3"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>3)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisisjawabansiswa/'.$id_mapel.'/uh4" title="Analisis Jawaban Siswa UH4"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>4)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisisjawabansiswa/'.$id_mapel.'/uh5" title="Analisis Jawaban Siswa UH5" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>5)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisisjawabansiswa/'.$id_mapel.'/uh6" title="Analisis Jawaban Siswa UH6" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>6)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisisjawabansiswa/'.$id_mapel.'/uh7" title="Analisis Jawaban Siswa UH7" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>7)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisisjawabansiswa/'.$id_mapel.'/uh8" title="Analisis Jawaban Siswa UH8" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>8)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisisjawabansiswa/'.$id_mapel.'/uh9" title="Analisis Jawaban Siswa UH9" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>9)
{echo '<td align="center"><a href="'.base_url().'bimtik/analisisjawabansiswa/'.$id_mapel.'/uh10" title="Analisis Jawaban Siswa UH10" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
echo '<tr><td align="center"></td><td>Hasil Analisis</td>';
if ($cacah_ulangan_harian>0)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh1" title="Lihat Hasil Analisis UH1"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>1)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh2" title="Lihat Hasil Analisis UH2"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>2)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh3" title="Lihat Hasil Analisis UH3"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>3)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh4" title="Lihat Hasil Analisis UH4"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>4)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh5" title="Lihat Hasil Analisis UH5" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>5)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh6" title="Lihat Hasil Analisis UH6" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>6)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh7" title="Lihat Hasil Analisis UH7" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>7)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh8" title="Lihat Hasil Analisis UH8" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>8)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh9" title="Lihat Hasil Analisis UH9" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>9)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh10" title="Lihat Hasil Analisis UH10" target="_blank"><span class="fa fa-bullseye"></span></a></td>';}
echo '</tr>';
echo '<tr><td align="center"></td><td>hasil analisis ditandatangani kepala</td>';
if ($cacah_ulangan_harian>0)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh1/ttd" title="Lihat Hasil Analisis UH1"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>1)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh2/ttd" title="Lihat Hasil Analisis UH2"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>2)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh3/ttd" title="Lihat Hasil Analisis UH3"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>3)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh4/ttd" title="Lihat Hasil Analisis UH4"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>4)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh5/ttd" title="Lihat Hasil Analisis UH5" ><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>5)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh6/ttd" title="Lihat Hasil Analisis UH6" ><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>6)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh7/ttd" title="Lihat Hasil Analisis UH7" ><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>7)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh8/ttd" title="Lihat Hasil Analisis UH8" ><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>8)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh9/ttd" title="Lihat Hasil Analisis UH9" ><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>9)
{echo '<td align="center"><a href="'.base_url().'bimtik/hasilanalisis/'.$id_mapel.'/uh10/ttd" title="Lihat Hasil Analisis UH10" ><span class="fa fa-bullseye"></span></a></td>';}
echo '</tr>';
//data tindaklanjut
echo '<tr><td align="center"></td><td>Program Remidial / Pengayaan</td>';
if ($cacah_ulangan_harian>0)
{echo '<td align="center"><a href="'.base_url().'bimtik/tindaklanjut/'.$id_mapel.'/uh1" title="Data Tanggal Pelaksanaan, Tindakan dsb"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>1)
{echo '<td align="center"><a href="'.base_url().'bimtik/tindaklanjut/'.$id_mapel.'/uh2" title="Data Tanggal Pelaksanaan, Tindakan dsb"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>2)
{echo '<td align="center"><a href="'.base_url().'bimtik/tindaklanjut/'.$id_mapel.'/uh3" title="Data Tanggal Pelaksanaan, Tindakan dsb"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>3)
{echo '<td align="center"><a href="'.base_url().'bimtik/tindaklanjut/'.$id_mapel.'/uh4" title="Data Tanggal Pelaksanaan, Tindakan dsb"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>4)
{echo '<td align="center"><a href="'.base_url().'bimtik/tindaklanjut/'.$id_mapel.'/uh5" title="Data Tanggal Pelaksanaan, Tindakan dsb untuk tindak lanjut UH5" ><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>5)
{echo '<td align="center"><a href="'.base_url().'bimtik/tindaklanjut/'.$id_mapel.'/uh6" title="Data Tanggal Pelaksanaan, Tindakan dsb untuk tindak lanjut UH6" ><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>6)
{echo '<td align="center"><a href="'.base_url().'bimtik/tindaklanjut/'.$id_mapel.'/uh7" title="Data Tanggal Pelaksanaan, Tindakan dsb untuk tindak lanjut UH7" ><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>7)
{echo '<td align="center"><a href="'.base_url().'bimtik/tindaklanjut/'.$id_mapel.'/uh8" title="Data Tanggal Pelaksanaan, Tindakan dsb untuk tindak lanjut UH8" ><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>8)
{echo '<td align="center"><a href="'.base_url().'bimtik/tindaklanjut/'.$id_mapel.'/uh9" title="Data Tanggal Pelaksanaan, Tindakan dsb untuk tindak lanjut UH9" ><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>9)
{echo '<td align="center"><a href="'.base_url().'bimtik/tindaklanjut/'.$id_mapel.'/uh10" title="Data Tanggal Pelaksanaan, Tindakan dsb untuk tindak lanjut UH10" ><span class="fa fa-bullseye"></span></a></td>';}
echo '</tr>';
//rancangan remidial
echo '<tr><td align="center"></td><td>Rancangan Program Remidial</td>';
if ($cacah_ulangan_harian>0)
{echo '<td align="center"><a href="'.base_url().'akreditasi/rancanganremidial/'.$id_mapel.'/uh1" title="Rancangan Program Remidial UH1"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>1)
{echo '<td align="center"><a href="'.base_url().'akreditasi/rancanganremidial/'.$id_mapel.'/uh2" title="Rancangan Program Remidial UH2"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>2)
{echo '<td align="center"><a href="'.base_url().'akreditasi/rancanganremidial/'.$id_mapel.'/uh3" title="Rancangan Program Remidial UH3"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>3)
{echo '<td align="center"><a href="'.base_url().'akreditasi/rancanganremidial/'.$id_mapel.'/uh4" title="Rancangan Program Remidial UH4"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>4)
{echo '<td align="center"><a href="'.base_url().'bimtik/rancanganremidial/'.$id_mapel.'/uh5" title="Rancangan Program Remidial UH5" ><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>5)
{echo '<td align="center"><a href="'.base_url().'bimtik/rancanganremidial/'.$id_mapel.'/uh6" title="Rancangan Program Remidial UH6" ><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>6)
{echo '<td align="center"><a href="'.base_url().'bimtik/rancanganremidial/'.$id_mapel.'/uh7" title="Rancangan Program Remidial UH7" ><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>7)
{echo '<td align="center"><a href="'.base_url().'bimtik/rancanganremidial/'.$id_mapel.'/uh8" title="Rancangan Program Remidial UH8" ><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>8)
{echo '<td align="center"><a href="'.base_url().'bimtik/rancanganremidial/'.$id_mapel.'/uh9" title="Rancangan Program Remidial UH9" ><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>9)
{echo '<td align="center"><a href="'.base_url().'bimtik/rancanganremidial/'.$id_mapel.'/uh10" title="Rancangan Program Remidial UH10" ><span class="fa fa-bullseye"></span></a></td>';}
echo '<td colspan="2"></td></tr>';
echo '<tr><td align="center"></td><td>Pengayaan</td>';
if ($cacah_ulangan_harian>0)
{echo '<td align="center"><a href="'.base_url().'bimtik/pengayaan/'.$id_mapel.'/uh1" title="Lihat Peserta Program Pengayaan UH1"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>1)
{echo '<td align="center"><a href="'.base_url().'bimtik/pengayaan/'.$id_mapel.'/uh2" title="Lihat Peserta Program Pengayaan UH2"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>2)
{echo '<td align="center"><a href="'.base_url().'bimtik/pengayaan/'.$id_mapel.'/uh3" title="Lihat Peserta Program Pengayaan UH3"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>3)
{echo '<td align="center"><a href="'.base_url().'bimtik/pengayaan/'.$id_mapel.'/uh4" title="Lihat Peserta Program Pengayaan UH4"><span class="fa fa-bullseye"></span></a></td>';}
		if($cacah_ulangan_harian>4)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>5)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>6)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>7)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>8)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>9)
		{
			echo '<td align="center"></td>';
		}
echo '<td colspan="2"></td></tr>';
echo '<tr><td align="center"></td><td>Pengayaan ditandatangani kepala</td>';
if ($cacah_ulangan_harian>0)
{echo '<td align="center"><a href="'.base_url().'bimtik/pengayaan/'.$id_mapel.'/uh1/ttd" title="Lihat Peserta Program Pengayaan UH1"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>1)
{echo '<td align="center"><a href="'.base_url().'bimtik/pengayaan/'.$id_mapel.'/uh2/ttd" title="Lihat Peserta Program Pengayaan UH2"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>2)
{echo '<td align="center"><a href="'.base_url().'bimtik/pengayaan/'.$id_mapel.'/uh3/ttd" title="Lihat Peserta Program Pengayaan UH3"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>3)
{echo '<td align="center"><a href="'.base_url().'bimtik/pengayaan/'.$id_mapel.'/uh4/ttd" title="Lihat Peserta Program Pengayaan UH4"><span class="fa fa-bullseye"></span></a></td>';}
		if($cacah_ulangan_harian>4)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>5)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>6)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>7)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>8)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>9)
		{
			echo '<td align="center"></td>';
		}
echo '<td colspan="2"></td></tr>';
//nilai remidial
//impor 
echo '<tr><td align="center"></td><td>Nilai Remidi</td>';
if ($cacah_ulangan_harian>0)
{echo '<td align="center"><a href="'.base_url().'bimtik/nilairemidi/'.substr($thnajaran,0,4).'/'.$semester.'/'.$id_mapel.'/uh1" title="Daftar Nilai Remidi UH1"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>1)
{echo '<td align="center"><a href="'.base_url().'bimtik/nilairemidi/'.substr($thnajaran,0,4).'/'.$semester.'/'.$id_mapel.'/uh2" title="Daftar Nilai Remidi UH2"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>2)
{echo '<td align="center"><a href="'.base_url().'bimtik/nilairemidi/'.substr($thnajaran,0,4).'/'.$semester.'/'.$id_mapel.'/uh3" title="Daftar Nilai Remidi UH3"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>3)
{echo '<td align="center"><a href="'.base_url().'bimtik/nilairemidi/'.substr($thnajaran,0,4).'/'.$semester.'/'.$id_mapel.'/uh4" title="Daftar Nilai Remidi UH4"><span class="fa fa-bullseye"></span></a></td>';}
		if($cacah_ulangan_harian>4)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>5)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>6)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>7)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>8)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>9)
		{
			echo '<td align="center"></td>';
		}
echo '<td colspan="2"></td></tr>';
//ketuntasan
echo '<tr><td align="center"></td><td>Ketuntasan</td>';
if ($cacah_ulangan_harian>0)
{echo '<td align="center"><a href="'.base_url().'bimtik/ketuntasan/'.substr($thnajaran,0,4).'/'.$semester.'/uh1" title="Lihat Ketuntasan UH1"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>1)
{echo '<td align="center"><a href="'.base_url().'bimtik/ketuntasan/'.$id_mapel.'/uh2" title="Lihat Ketuntasan UH2"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>2)
{echo '<td align="center"><a href="'.base_url().'bimtik/ketuntasan/'.$id_mapel.'/uh3" title="Lihat Ketuntasan UH3"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>3)
{echo '<td align="center"><a href="'.base_url().'bimtik/ketuntasan/'.$id_mapel.'/uh4" title="Lihat Ketuntasan UH4"><span class="fa fa-bullseye"></span></a></td>';}
		if($cacah_ulangan_harian>4)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>5)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>6)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>7)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>8)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>9)
		{
			echo '<td align="center"></td>';
		}
echo '<td colspan="2"></td></tr>';
//ketuntasan di tandatangani kepala
echo '<tr><td align="center"></td><td>Ketuntasan ditandatangani kepala</td>';
if ($cacah_ulangan_harian>0)
{echo '<td align="center"><a href="'.base_url().'bimtik/ketuntasan/'.$id_mapel.'/uh1/ttd" title="Lihat Ketuntasan UH1"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>1)
{echo '<td align="center"><a href="'.base_url().'bimtik/ketuntasan/'.$id_mapel.'/uh2/ttd" title="Lihat Ketuntasan UH2"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>2)
{echo '<td align="center"><a href="'.base_url().'bimtik/ketuntasan/'.$id_mapel.'/uh3/ttd" title="Lihat Ketuntasan UH3"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>3)
{echo '<td align="center"><a href="'.base_url().'bimtik/ketuntasan/'.$id_mapel.'/uh4/ttd" title="Lihat Ketuntasan UH4"><span class="fa fa-bullseye"></span></a></td>';}
		if($cacah_ulangan_harian>4)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>5)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>6)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>7)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>8)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>9)
		{
			echo '<td align="center"></td>';
		}
echo '<td colspan="2"></td></tr>';

//impor 
echo '<tr><td align="center"></td><td>Impor Nilai</td>';
if ($cacah_ulangan_harian>0)
{echo '<td align="center"><a href="'.base_url().'bimtik/unggahnilai/'.$id_mapel.'/uh1" title="Impor Nilai UH1"><span class="fa fa-bullseye"></span></a></td><td align="center"><a href="'.base_url().'bimtik/unggahnilai/'.$id_mapel.'/tu1" title="Impor Nilai keterampilan 1"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>1)
{echo '<td align="center"><a href="'.base_url().'bimtik/unggahnilai/'.$id_mapel.'/uh2" title="Impor Nilai UH2"><span class="fa fa-bullseye"></span></a></td><td align="center"><a href="'.base_url().'bimtik/unggahnilai/'.$id_mapel.'/tu2" title="Impor Nilai keterampilan 2"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>2)
{echo '<td align="center"><a href="'.base_url().'bimtik/unggahnilai/'.$id_mapel.'/uh3" title="Impor Nilai UH3"><span class="fa fa-bullseye"></span></a></td><td align="center"><a href="'.base_url().'bimtik/unggahnilai/'.$id_mapel.'/tu3" title="Impor Nilai keterampilan 3"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>3)
{echo '<td align="center"><a href="'.base_url().'bimtik/unggahnilai/'.$id_mapel.'/uh4" title="Impor Nilai UH4"><span class="fa fa-bullseye"></span></a></td><td align="center"><a href="'.base_url().'bimtik/unggahnilai/'.$id_mapel.'/tu4" title="Impor Nilai keterampilan 4"><span class="fa fa-bullseye"></span></a></td>';}
		if($cacah_ulangan_harian>4)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>5)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>6)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>7)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>8)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>9)
		{
			echo '<td align="center"></td>';
		}
echo '<td colspan="2"></td></tr>';
//impor nilai remidial
echo '<tr><td align="center"></td><td>Impor Nilai Remidial</td>';
if ($cacah_ulangan_harian>0)
{echo '<td align="center"><a href="'.base_url().'bimtik/imporremidial/'.$id_mapel.'/uh1" title="Impor Nilai Remidial UH1"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>1)
{echo '<td align="center"><a href="'.base_url().'bimtik/imporremidial/'.$id_mapel.'/uh2" title="Impor Nilai Remidial UH2"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>2)
{echo '<td align="center"><a href="'.base_url().'bimtik/imporremidial/'.$id_mapel.'/uh3" title="Impor Nilai Remidial UH3"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>3)
{echo '<td align="center"><a href="'.base_url().'bimtik/imporremidial/'.$id_mapel.'/uh4" title="Impor Nilai Remidial UH4"><span class="fa fa-bullseye"></span></a></td>';}
		if($cacah_ulangan_harian>4)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>5)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>6)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>7)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>8)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>9)
		{
			echo '<td align="center"></td>';
		}
echo '<td colspan="2"></td></tr>';
//saran
echo '<tr><td align="center"></td><td>Komentar / Saran</td>';
if ($cacah_ulangan_harian>0)
{echo '<td align="center"><a href="'.base_url().'akreditasi/saran/'.$id_mapel.'/uh1" title="Komentar / Saran hasil UH1"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>1)
{echo '<td align="center"><a href="'.base_url().'akreditasi/saran/'.$id_mapel.'/uh2" title="Komentar / Saran hasil UH2"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>2)
{echo '<td align="center"><a href="'.base_url().'akreditasi/saran/'.$id_mapel.'/uh3" title="Komentar / Saran hasil UH3"><span class="fa fa-bullseye"></span></a></td>';}
if ($cacah_ulangan_harian>3)
{echo '<td align="center"><a href="'.base_url().'akreditasi/saran/'.$id_mapel.'/uh4" title="Komentar / Saran hasil UH4"><span class="fa fa-bullseye"></span></a></td>';}
		if($cacah_ulangan_harian>4)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>5)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>6)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>7)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>8)
		{
			echo '<td align="center"></td>';
		}
		if($cacah_ulangan_harian>9)
		{
			echo '<td align="center"></td>';
		}
echo '<td colspan="2"></td></tr>';
}
else{
echo '<tr><td colspan="5">Belum ada daftar nilai semester ini</td></tr>';
}
?>
</table></div>
<?php
echo '* : Klasikal bila persentase cacah siswa di atas kkm &gt; '.$this->config->item('persentase_klasikal').'<br />';
if ((!empty($id_mapel)) and (!empty($kelas)) and (!empty($thnajaran)) and (!empty($semester))) 
{
	echo form_open('bimtik/perbaruidaftarsiswa');?>
		<input type="hidden" name="id_mapel" value="<?php echo $id_mapel;?>">
			<input type="hidden" name="kelas" value="<?php echo $kelas;?>">
			<input type="hidden" name="thnajaran" value="<?php echo $thnajaran;?>">
			<input type="hidden" name="kurikulum" value="<?php echo $kurikulum;?>">
			<input type="hidden" name="semester" value="<?php echo $semester;?>">
			<input type="hidden" name="kkm" value="<?php echo $kkm;?>">
			<p class="text-center"><input type="submit" value="Perbarui Daftar Siswa" class="btn btn-primary"></p>
	</form>
	<?php
}
?>
</div>
