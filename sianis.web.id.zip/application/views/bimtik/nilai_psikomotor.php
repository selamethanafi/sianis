<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//============================================================+
// Nama Berkas 		: nilai_psikomotor.php
// Dimutakhirkan 	: Rab 11 Mei 2016 22:10:37 WIB 
// Lokasi      		: application/views/guru
// Author      		: Selamet Hanafi
//	    		  selamethanafi@yahoo.co.id
//
// (c) Copyright:
//               Sianis
//               www.sianis.web.id
//               selamet.hanafi@gmail.com
//
// License:
//    Copyright (C) 2014 Sianis
//    Informasi detil ada di LISENSI.TXT 
//============================================================+
?><div class="container-fluid"><h2><?php echo $judulhalaman;?></h2>
<a href="<?php echo base_url(); ?>bimtik/daftarnilaipsikomotor/<?php echo $id_mapel;?>"><span class="glyphicon glyphicon-arrow-left"></span><b> Kembali</b></a>
<?php
$tap = $this->db->query("select * from bimtik_aspek_psikomotorik where thnajaran='$thnajaran' and semester='$semester' and kelas='$kelas'");
foreach($tap->result () as $dap)
{
	if ($itemnilai<19)
	{
	$iteme = "p".$itemnilai;
	$penilaian = $dap->$iteme;
	}
	else
	{
	$penilaian = 'Nilai Akhir Psikomotor / Keterampilan';
	}
	$cacahitem = $dap->np;
}
?>
<form class="form-horizontal" role="form">
    <div class="form-group row">
		<div class="col-sm-3"><label for="thnajaran" class="control-label">Tahun Pelajaran</label></div>
		<div class="col-sm-9" ><p class="form-control-static"><?php echo $thnajaran;?></p></div>
		<div class="col-sm-3"><label for="semester" class="control-label">Semester</label></div>
		<div class="col-sm-9" ><p class="form-control-static"><?php echo $semester;?></p></div>
		<div class="col-sm-3"><label for="kelas" class="control-label">Kelas</label></div>
		<div class="col-sm-9" ><p class="form-control-static"><?php echo $kelas;?></p></div>
		<div class="col-sm-3"><label for="penilaian" class="control-label">Penilaian</label></div>
		<div class="col-sm-9" ><p class="form-control-static"><?php echo $penilaian;?></p></div>
		<div class="col-sm-3"><label for="cacahitempenilaian" class="control-label">Cacah kriteria penilaian</label></div>
		<div class="col-sm-9" ><p class="form-control-static"><?php echo $cacahitem;?></p></div>

    </div>
</form>
<?php echo form_open('bimtik/updatenilaipsikomotor');?>
<div class="table-responsive">
<table class="table table-hover table-bordered">
<tr align="center"><td><strong>No.</strong></td><td><strong>Nama</strong></td>
<?php
if(!empty($dap->p1))
{
	echo '<td><strong>'.substr($dap->p1,0,1).'</strong></td>';
}
if(!empty($dap->p2))
{
	echo '<td><strong>'.substr($dap->p2,0,1).'</strong></td>';
}
if(!empty($dap->p3))
{
	echo '<td><strong>'.substr($dap->p3,0,1).'</strong></td>';
}
if(!empty($dap->p4))
{
	echo '<td><strong>'.substr($dap->p4,0,1).'</strong></td>';
}
if(!empty($dap->p5))
{
	echo '<td><strong>'.substr($dap->p5,0,1).'</strong></td>';
}
if(!empty($dap->p6))
{
	echo '<td><strong>'.substr($dap->p6,0,1).'</strong></td>';
}
if(!empty($dap->p7))
{
	echo '<td><strong>'.substr($dap->p7,0,1).'</strong></td>';
}
if(!empty($dap->p8))
{
	echo '<td><strong>'.substr($dap->p8,0,1).'</strong></td>';
}
if(!empty($dap->p9))
{
	echo '<td><strong>'.substr($dap->p9,0,1).'</strong></td>';
}
if(!empty($dap->p10))
{
	echo '<td><strong>'.substr($dap->p10,0,1).'</strong></td>';
}
if(!empty($dap->p11))
{
	echo '<td><strong>'.substr($dap->p11,0,1).'</strong></td>';
}
if(!empty($dap->p12))
{
	echo '<td><strong>'.substr($dap->p12,0,1).'</strong></td>';
}
if(!empty($dap->p13))
{
	echo '<td><strong>'.substr($dap->p13,0,1).'</strong></td>';
}
if(!empty($dap->p14))
{
	echo '<td><strong>'.substr($dap->p14,0,1).'</strong></td>';
}
if(!empty($dap->p15))
{
	echo '<td><strong>'.substr($dap->p15,0,1).'</strong></td>';
}
if(!empty($dap->p16))
{
	echo '<td><strong>'.substr($dap->p16,0,1).'</strong></td>';
}
if(!empty($dap->p17))
{
	echo '<td><strong>'.substr($dap->p17,0,1).'</strong></td>';
}
if(!empty($dap->p18))
{
	echo '<td><strong>'.substr($dap->p18,0,1).'</strong></td>';
}
echo '<td align="center">Nilai</td><td><strong>Nilai Akhir</strong></td></tr>';
$nomor=1;
if(count($query->result())>0)
{
	foreach($query->result() as $t)
	{
		$nis = $t->nis;
		echo "<tr><td>";
		echo '<input type="hidden" name="nis_'.$nomor.'" value ="'.$t->nis.'" ><input type="hidden" name="id_psikomotor_'.$nomor.'"  value ='.$t->id_psikomotor.'>';
		echo $nomor."</td><td>".nis_ke_nama($t->nis)."</td>";
		if($cacahitem>0)
		{
			$ratarata = ($t->p1 + $t->p2 + $t->p3 + $t->p4 + $t->p5 + $t->p6 + $t->p7 + $t->p8 + $t->p9 + $t->p10 + $t->p11 + $t->p12 + $t->p13 + $t->p14 + $t->p15 + $t->p16 + $t->p17 + $t->p18) / $cacahitem;
		}
		$ratarata = round($ratarata,2);

		$iteme = 1;
		do
		{
			$ite = "p$iteme";
			if(!empty($dap->$ite))
			{		
				if ($itemnilai=="$iteme")
				{
				echo '<td align="center" width="100"><input type="number" min="0" max="100" name="p'.$iteme.'_'.$nomor.'" value ="'.$t->$ite.'" class="form-control"  min="0" max="100"></td>';
				}
				else
				{
				echo '<td align="center"><input type="hidden" name="p'.$iteme.'_'.$nomor.'" value ="'.$t->$ite.'" >'.$t->$ite.'</td>';
				}
			}
		$iteme++;
		}
		while ($iteme<19);
			$ta = $this->db->query("select `thnajaran`,`semester`,`nis`, `psi`,`kunci` from `bimtik_nilai` where `thnajaran`='$thnajaran' and `semester`='$semester' and `nis`='$nis'");
			$psi = $t->nilai_akhir;
			$terkunci = 0;

			foreach($ta->result() as $a)
			{
				$psi = $a->psi;
				$terkunci = $a->kunci;
			}
			echo '<td align="center">'.$ratarata.'</td>';
		if ($itemnilai=="19")
			{
			if ($terkunci == 1)
				{
				echo '<td align="center"><input type="hidden" name="p'.$iteme.'_'.$nomor.'" value ="'.$psi.'">'.$psi.'</td>';
				}
				else
				{
				echo '<td align="center" width="100"><input type="number" name="p'.$iteme.'_'.$nomor.'" value ="'.$psi.'" class="form-control" min="0" max="100"></td>';
				}
			}
			else
			{
			echo '<td align="center"><input type="hidden" name="p'.$iteme.'_'.$nomor.'" value ="'.$psi.'" >'.$psi.'</td>';
			}

		echo "</tr>";
	$nomor++;	
	}
}
else{
echo "<tr><td colspan='5'>Belum ada daftar nilai</td></tr>";
}
?>
</table></div>
	 <?php $cacah_siswane = $nomor - 1;?>
	<input type="hidden" name="cacahitem" value ="<?php echo $cacahitem;?>">
	<input type="hidden" name="cacah_siswa" value ="<?php echo $cacah_siswane;?>">
	<input type="hidden" name="thnajaran" value ="<?php echo $thnajaran;?>">
	<input type="hidden" name="semester" value="<?php echo $semester;?>">
	<input type="hidden" name="itemnilai" value="<?php echo $itemnilai;?>">
	<input type="hidden" name="id_mapel" value="<?php echo $id_mapel;?>">
<?php
if ((!empty($id_mapel)) and (!empty($semester)) and (!empty($kelas)) and (!empty($thnajaran)) and (!empty($semester))) 
{
	if (($itemnilai==1) or ($itemnilai==2) or ($itemnilai==3) or ($itemnilai==4) or ($itemnilai==5) or ($itemnilai==6) or ($itemnilai==7) or ($itemnilai==8) or ($itemnilai==9) or ($itemnilai==10) or ($itemnilai==11) or ($itemnilai==12) or ($itemnilai==13) or ($itemnilai==14) or ($itemnilai==15) or ($itemnilai==16) or ($itemnilai==17) or ($itemnilai==18) or ($itemnilai==19))
	{
	?>
	<p class="text-center"><button type="submit" class="btn btn-primary">Simpan</button></p>
	<?php
	}
	?>
</form>
<?php
}
?>

</div>
