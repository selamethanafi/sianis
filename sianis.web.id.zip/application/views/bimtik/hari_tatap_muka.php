	<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//============================================================+
// Nama Berkas : hari_tatap_muka.php
// Lokasi      : application/views/guru
// Author      : Selamet Hanafi
//               selamethanafi@yahoo.co.id
//
// (c) Copyright:
//               Selamet Hanafi
//               sianis.web.id
//               selamet.hanafi@gmail.com
//
// License:
//    Copyright (C) 2014 Selamet Hanafi
//    Informasi detil ada di LISENSI.TXT 
//============================================================+
?>
<div class="container-fluid">
<div class="card">
<div class="card-header"><h3><?php echo $judulhalaman;?></h3></div>
<div class="card-body">
<?php
if ($is_new=='yes')
{
	$this->db->query("INSERT INTO `bimtik_haritatapmuka` (`id_mapel`, `hari_tatap_muka`,`jam_ke`,`kodeguru`,`jtm`) VALUES ('$id_mapel', '$hari_tatap_muka','$jam_ke','$kodeguru','$jtm')");
}
if ($is_new=='no')
{
	$this->db->query("update `bimtik_haritatapmuka` set `hari_tatap_muka`='$hari_tatap_muka',`jam_ke`='$jam_ke', `kodeguru`='$kodeguru', `jtm`='$jtm',`id_mapel`='$id_mapel' where id_hari_tatap_muka='$id_hari'");
}
if ($aksi=='hapus')
{
	$this->db->query("delete from `bimtik_haritatapmuka` where `id_hari_tatap_muka`='$id_hari_tatap_muka' and kodeguru='$kodeguru'");
	$aksi = '';	
}
if($aksi=='tambah')
{
	echo form_open('bimtik/haritatapmuka','class="form-horizontal" role="form"');
	echo '<div class="form-group row"><div class="col-sm-3"><label class="control-label">Tahun Pelajaran</label></div><div class="col-sm-9"><p class="form-control-static">'.$thnajaran.'</p></div></div>
	<div class="form-group row"><div class="col-sm-3"><label class="control-label">Semester</label></div><div class="col-sm-9"><p class="form-control-static">'.$semester.'</p></div></div>';
	echo '<div class="form-group row"><div class="col-sm-3"><label class="control-label">Kelas</label></div><div class="col-sm-9">';
	$tb = $this->db->query("select * from `bimtik_mapel` where kodeguru='$kodeguru' and thnajaran='$thnajaran' and semester='$semester' order by `kelas`");
		echo '<select name="id_mapel" class="form-control">';
	foreach ($tb->result() as $b)
	{
		echo '<option value="'.$b->id_mapel.'">'.$b->mapel.' '.$b->kelas.'</option>';
	}
	echo '</select></div></div>
	<div class="form-group row"><div class="col-sm-3"><label class="control-label">Hari Tatap Muka</label></div><div class="col-sm-9"><select name="hari_tatap_muka" class="form-control">
	<option value=""></option>
	<option value="Monday">Senin</option>
	<option value="Tuesday">Selasa</option>
	<option value="Wednesday">Rabu</option>
	<option value="Thursday">Kamis</option>
	<option value="Friday">Jumat</option>
	<option value="Saturday">Sabtu</option>
	</select></div></div>
	<div class="form-group row"><div class="col-sm-3"><label class="control-label">Cacah Jam</label></div><div class="col-sm-9"><select name="jtm" class="form-control">
	<option value="1">1</option>
	<option value="2">2</option>
	<option value="3">3</option>
	<option value="4">4</option>
	</select></div></div>
	<div class="form-group row"><div class="col-sm-3"><label class="control-label">Jam ke -</label></div><div class="col-sm-9"><input type="text" name="jam_ke" class="form-control"></div></div>';
	echo '<p class="text-center"><input type="submit" value="Tambah Hari" class="btn btn-primary"><input type="hidden" name="is_new" value="yes">
	<a href="'.base_url().'bimtik/haritatapmuka/" class="btn btn-info"><b> Batal</b></a></p></form>';
	}//akhir tambah
elseif($aksi=='ubah')
	{
	echo form_open('bimtik/haritatapmuka','class="form-horizontal" role="form"');
	$tc = $this->db->query("select * from `bimtik_haritatapmuka` where `id_hari_tatap_muka`='$id_hari_tatap_muka'");
	foreach($tc->result() as $c)
	{
		$harine = day_to_hari($c->hari_tatap_muka);
		$id_mapel = $c->id_mapel;
		$jam_ke = $c->jam_ke;
		$jtm = $c->jtm;
	}
	

	echo '<div class="form-group row"><div class="col-sm-3"><label class="control-label">Tahun Pelajaran</label></div><div class="col-sm-9">'.$thnajaran.'</div></div>
	<div class="form-group row"><div class="col-sm-3"><label class="control-label">Semester</label></div><div class="col-sm-9">'.$semester.'</div></div>';
	echo '<div class="form-group row"><div class="col-sm-3"><label class="control-label">Mapel / Kelas</label></div><div class="col-sm-9">';
	$td = $this->db->query("select * from bimtik_mapel where `id_mapel` = '$id_mapel'");
	foreach($td->result() as $d)
	{
		$kelas = $d->kelas;
	}
	echo '<select name="id_mapel" class="form-control">';
	echo '<option value="'.$id_mapel.'">'.$kelas.'</option>';
	$tb = $this->db->query("select * from bimtik_mapel where kodeguru='$kodeguru' and thnajaran='$thnajaran' and semester='$semester' order by kelas");
	foreach ($tb->result() as $b)
	{
		echo '<option value="'.$b->id_mapel.'"> '.$b->kelas.'</option>';
	}
	echo '</select></div></div>
	<div class="form-group row"><div class="col-sm-3"><label class="control-label">Hari Tatap Muka</label></div><div class="col-sm-9"><select name="hari_tatap_muka" class="form-control">
	<option value="'.$c->hari_tatap_muka.'">'.$harine.'</option>
	<option value="Monday">Senin</option>
	<option value="Tuesday">Selasa</option>
	<option value="Wednesday">Rabu</option>
	<option value="Thursday">Kamis</option>
	<option value="Friday">Jumat</option>
	<option value="Saturday">Sabtu</option>
	</select></div></div>
	<div class="form-group row"><div class="col-sm-3"><label class="control-label">Cacah Jam</label></div><div class="col-sm-9"><select name="jtm" class="form-control">
	<option value="'.$jtm.'">'.$jtm.'</option>
	<option value="1">1</option>
	<option value="2">2</option>
	<option value="3">3</option>
	<option value="4">4</option>
	</select></div></div>

	<div class="form-group row"><div class="col-sm-3"><label class="control-label">Jam ke -</label></div><div class="col-sm-9"><input type="text" name="jam_ke" value="'.$jam_ke.'" class="form-control"><input type="hidden" name="id_hari" value="'.$id_hari_tatap_muka.'"></div></div>';
	echo '<p class="text-center"><input type="submit" value="Ubah Data" class="btn btn-primary"><input type="hidden" name="is_new" value="no"><input type="hidden" name="id_hari_tatap_muka" value="'.$id_hari_tatap_muka.'">
	<a href="'.base_url().'bimtik/haritatapmuka" class="btn btn-info"><b> Batal</b></a></p></form>';
	}//akhir ubah
else
{
	echo '<p><a href="'.base_url().'bimtik/haritatapmuka/tambah" class="btn btn-info"><b>Tambah Hari Tatap Muka</b></a></p>';
echo '<form class="form-horizontal" role="form"><div class="form-group row">
			<div class="col-sm-3"><label class="control-label">Tahun Pelajaran</label></div>
			<div class="col-sm-9"><p class="form-control-static">'.$thnajaran.'</p></div>
		</div>
		<div class="form-group row">
			<div class="col-sm-3"><label class="control-label">Semester</label></div>
			<div class="col-sm-9"><p class="form-control-static">'.$semester.'</p></div>
		</div>';
	echo '</form>';
$ta = $this->db->query("select * from `bimtik_mapel` where `thnajaran`='$thnajaran' and semester='$semester' and `kodeguru`='$kodeguru' order by kelas");
$adata  = $ta->num_rows();
if(count($ta->result())>0)
{
	?>
	<div class="table-responsive"><table class="table table-hover table-striped table-bordered">
<tr><td align="center"><strong>No</strong></td><td align="center"><strong>Kelas</strong></td><td align="center"><strong>Hari</strong></td><td align="center"><strong>Jam Ke-</strong></td><td align="center"><strong>JTM</strong></td><td align="center" colspan="2"><strong>Aksi</strong></td></tr>
<?php
$nomor=1;
	foreach($ta->result() as $a)
	{
		$id_mapel = $a->id_mapel;
		$tb = $this->db->query("select * from `bimtik_haritatapmuka` where `id_mapel`='$id_mapel'");
		foreach($tb->result() as $b)
		{
			$link_hapus = anchor('bimtik/haritatapmuka/hapus/'.$b->id_hari_tatap_muka,'<span class="fa fa-trash-alt"></span>', array('title' => 'Hapus', 'data-confirm' => 'Anda yakin akan menghapus data ini?'));
			$link_ubah = anchor('bimtik/haritatapmuka/ubah/'.$b->id_hari_tatap_muka,'<span class="fa fa-edit"></span>', array('title' => 'Ubah',''));
			$harine = day_to_hari($b->hari_tatap_muka);
			echo '<tr align="center"><td>'.$nomor.'</td><td>'.$a->kelas.'</td>';
			echo '<td>'.$harine.'</td><td>'.$b->jam_ke.'</td><td>'.$b->jtm.'</td><td align="center">'.$link_ubah.'</td><td align="center">'.$link_hapus.'</td></tr>';
			$nomor++;
		}

	}
echo '</table></div>';
}
else
{
echo 'Belum ada data';
}
}
?>
</div></div></div>
