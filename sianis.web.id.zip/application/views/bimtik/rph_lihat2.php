<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//============================================================+
// Nama Berkas : lihat_rph.php
// Lokasi      : application/views/guru/
// Author: Selamet Hanafi
//
// (c) Copyright:
//               Selamet Hanafi
//               sianis.web.id
//               selamet.hanafi@gmail.com
//
// License:
//    Copyright (C) 2009-2013 Selamet Hanafi
//    Informasi detil ada di LISENSI.TXT 
//============================================================+
?>
<div class="container-fluid">
<div class="card">
<div class="card-header"><h3><?php echo $judulhalaman;?></h3></div>
<div class="card-body">
<p><?php echo '<a href="'.base_url().'guru/rph2" class="btn btn-info">Tampil Semua RPH</a> <a href="'.base_url().'guru/rphlain2" class="btn btn-success">Tambah, Ubah RPH</a></p>';
if ( (!empty($thnajaran)) or (!empty($semester)) or (!empty($kelas)) or (!empty($kodeguru)) or (!empty($tanggalrph)))
{
?>
<div class="form-group row">
	<div class="col-sm-3"><label class="control-label">Tahun Pelajaran</label></div>
	<div class="col-sm-9"><p class="form-control-static"><?php echo $thnajaran;?></p></div>
</div>
<div class="form-group row">
	<div class="col-sm-3"><label class="control-label">Semester</label></div>
	<div class="col-sm-9"><p class="form-control-static"><?php echo $semester;?></p></div>
</div>
<?php
echo '<table class="table table-striped table-hover table-bordered">
<tr align="center"><td><strong>No.</strong></td><td><strong>Tanggal</strong></td><td><strong>Jam Ke-</strong></td><td><strong>Kelas</strong></td><td><strong>Kode RPP</strong></td><td><strong>Rencana</strong></td><td><strong>Keterangan</strong></td><td colspan="2"><strong>Aksi</div></div>';
$nomor =1;
$ta = $this->db->query("select * from `bimtik_rph` where `thnajaran` ='$thnajaran' and `semester`='$semester' and `kodeguru`='$kodeguru' and `kelas`='$kelas' and `tanggal`='$tanggalrph'");
foreach($ta->result() as $a)
{
	$dinane = tanggal_ke_hari($a->tanggal);
	$kode_rpp = $a->kode_rpp;
	$trpp = $this->db->query("select * from `bimtik_rpp` where `id_bimtik_rpp`='$kode_rpp'");
	$rencana ='';
	foreach($trpp->result() as $rpp)
	{
		$rencana = tanpa_tabel($rpp->rencana);
	}
	$link_ubah = anchor('bimtik/ubahrph/'.$a->id_rph,'<span class="fa fa-edit"></span>', array('title' => 'Ubah Rencana Harian', ''));
	$link_hapus = anchor('bimtik/hapusrph2/'.$a->id_rph,'<span class="fa fa-trash-alt"></span>', array('title' => 'Hapus', 'data-confirm' => 'Anda yakin ingin menghapus data RPH dan BPH ini?'));
	echo '<tr valign="top"><td>'.$nomor.'</td><td>'.$dinane.', '.date_to_long_string($a->tanggal).'</td><td>'.$a->jamke.'</td><td>'.$a->kelas.'</td><td><b>'.tanpa_paragraf($a->kode_rpp).'</b></td><td>'.tanpa_paragraf($rencana).'</td><td>'.tanpa_paragraf($a->keterangan).'</td><td align="center">'.$link_ubah.'</td><td align="center">'.$link_hapus.'</td></tr>';
	$nomor++;
	}
echo '</table>';
}
?>
</div></div></div>
