<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//============================================================+
// Nama Berkas : rpp.php
// Lokasi      : application/views/bimtik/
// Author      : Selamet Hanafi
//               selamethanafi@yahoo.co.id
//
// (c) Copyright:
//               Selamet Hanafi
//               sianis.web.id
//               selamet.hanafi@gmail.com
//
// License:
//    Copyright (C) 2014 Selamet Hanafi
//    Informasi detil ada di LISENSI.TXT 
//============================================================+
?>
<div class="container-fluid"><div class="card">
<div class="card-header"><h3><?php echo $judulhalaman;?></h3></div>
<div class="card-body">
<p><a href="<?php echo base_url(); ?>bimtik/rpp/tambah" class="btn btn-info"><b>Tambah RPP</b></a>&nbsp;&nbsp;&nbsp;
<a href="<?php echo base_url(); ?>bimtik/rpp/salin" class="btn btn-info"><b>Salin RPP </b></a>&nbsp;&nbsp;&nbsp;<a href="<?php echo base_url(); ?>bimtik/rpp/unduh" class="btn btn-info"><b>Unduh RPP</b></a>&nbsp;&nbsp;&nbsp;<a href="<?php echo base_url(); ?>unggah/unggahperangkat" class="btn btn-info"><b>Unggah RPP</b></a></p>
<?php
?>
<div class="table-responsive">
<table class="table table-hover table-striped table-bordered">
<tr align="center"><td><strong>Kode RPP.</strong></td><td><strong>No RPP.</strong></td><td><strong>Kelas</strong></td><td><strong>Materi</strong></td><td><strong>Ubah</strong></td><td><strong>Hapus</strong></td></tr>
<?php
$nomor=$page+1;
if(count($ta->result())>0){
foreach($ta->result() as $a)
{
	$link_hapus = anchor('bimtik/rpp/hapus/'.$a->id_bimtik_rpp,'<span class="fa fa-trash-alt"></span>', array('title' => 'Hapus', 'data-confirm' => 'Anda yakin akan menghapus data ini?'));
	$link_ubah = anchor('bimtik/rpp/ubah/'.$a->id_bimtik_rpp,'<span class="fa fa-edit"></span>', array('title' => 'Ubah',''));

echo "<tr valign=\"top\">
	<td align='center'>".$a->id_bimtik_rpp."</td>
	<td align='center'>".$a->no_rpp."</td>
	<td>".$a->kelas."</td>
	<td>".tanpa_paragraf($a->materi_pembelajaran)."</td>";
	echo '<td align="center">'.$link_ubah.'</a></td><td align="center">'.$link_hapus.'</td></tr>';
	$nomor++;	
}
}
else{
echo "<tr><td colspan='5'>Anda belum pernah menulis RPP</td></tr>";
}
?>
</table></div>
<?php
if (!empty($paginator))
{
	?>
	<div class="col-md-12 text-center">
	<?php echo $paginator;?></div>
	<?php }?>
</div></div>
</div>
