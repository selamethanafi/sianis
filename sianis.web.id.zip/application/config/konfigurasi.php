<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config['fonts_path'] = 'system/fonts/';
$config['versi_deskripsi'] = 'Versi Bawaan Sistem';
$config['awalttd'] = 'asws';
$config['bobot_ujian_tertulis'] = 60; //persen
$config['bobot_ujian_praktik'] = 40; //persen
$config['lokasi'] = 'Semarang';
